import type { OfferSectionDefinition } from '../../../engine/models/offer-section-definition';

const required = (message: string) => ({ required: true, message });
const yn = (path: string, label: string, message: string) => ({ id: path, type: 'yes_no' as const, label, fieldPath: path, validation: required(message) });

/** Terms are original NavStreet terms; these questions do not fill Utah's state PDF. */
export const UTAH_RESIDENTIAL_SALE_SECTIONS: readonly OfferSectionDefinition[] = [
  { id: 'parties', title: 'Buyers and sellers', description: 'Review the parties copied from the listing and account.', questions: [] },
  { id: 'property', title: 'Property and water', questions: [
    { id: 'legal-description', type: 'textarea', label: 'Recorded legal description supplied by the seller', fieldPath: 'legalDescription', readOnly: true, helpText: 'Copied from the seller’s listing when available. The buyer does not need to supply it; confirm the deed description with the title company before closing.', visibleWhen: { match: 'all', conditions: [{ fieldPath: 'legalDescription', operator: 'is_not_empty' }] } },
    { id: 'included', type: 'textarea', label: 'Additional items included', fieldPath: 'propertyItems.included', placeholder: 'Appliances or other items included by agreement' },
    { id: 'excluded', type: 'textarea', label: 'Items excluded', fieldPath: 'propertyItems.excluded' },
    yn('propertyItems.waterRightsIncluded', 'Are any water rights or shares included?', 'Select whether any water rights or shares are included.'),
    { id: 'excluded-water', type: 'textarea', label: 'Water rights excluded or transfer details', fieldPath: 'propertyItems.excludedWaterRights', helpText: 'Describe specific exclusions or special transfer requirements.' },
  ] },
  { id: 'purchase', title: 'Price, deposit, and financing', questions: [
    { id: 'price', type: 'currency', label: 'Purchase price', fieldPath: 'purchase.purchasePriceInCents', validation: { required: true, minimum: 1, message: 'Enter a purchase price above $0.' } },
    { id: 'deposit', type: 'currency', label: 'Earnest money deposit', fieldPath: 'purchase.earnestMoneyInCents', validation: { required: true, minimum: 1, message: 'Enter an earnest money deposit above $0.' } },
    { id: 'holder', type: 'text', label: 'Independent escrow or title holder', fieldPath: 'purchase.earnestMoneyHolder', validation: required('Identify the party that will hold earnest money.') },
    { id: 'due-days', type: 'number', label: 'Days after acceptance to deliver earnest money', fieldPath: 'purchase.earnestMoneyDueDays', validation: { required: true, minimum: 1, maximum: 30, message: 'Enter 1 to 30 days.' } },
    { id: 'funding', type: 'single_choice', label: 'How will the purchase be funded?', fieldPath: 'purchase.financingType', validation: required('Select cash or a loan type.'), options: [
      { value: 'cash', label: 'Cash' }, { value: 'conventional', label: 'Conventional loan' }, { value: 'fha', label: 'FHA loan' }, { value: 'va', label: 'VA loan' }, { value: 'usda', label: 'USDA loan' },
    ] },
    { id: 'loan', type: 'currency', label: 'Expected loan amount', fieldPath: 'purchase.loanAmountInCents', visibleWhen: { match: 'all', conditions: [{ fieldPath: 'purchase.financingType', operator: 'not_equals', value: 'cash' }, { fieldPath: 'purchase.financingType', operator: 'not_equals', value: 'unselected' }] }, validation: { required: true, minimum: 1, message: 'Enter an expected loan amount above $0.' } },
    { id: 'concessions', type: 'currency', label: 'Seller concessions', fieldPath: 'purchase.sellerConcessionsInCents' },
    { id: 'extra-deposit', type: 'currency', label: 'Additional earnest money, if agreed', fieldPath: 'purchase.additionalEarnestMoneyInCents', visibleWhen: { match: 'all', conditions: [{ fieldPath: 'conditions.additionalEarnestMoney', operator: 'is_true' }] } },
  ] },
  { id: 'conditions', title: 'Purchase conditions', description: 'Select each condition explicitly; an unchecked condition changes your rights.', questions: [
    yn('conditions.dueDiligence', 'Conditioned on due diligence?', 'Select the due diligence condition.'),
    yn('conditions.appraisal', 'Conditioned on appraisal?', 'Select the appraisal condition.'),
    yn('conditions.financing', 'Conditioned on financing?', 'Select the financing condition.'),
    yn('conditions.saleOfBuyersProperty', 'Conditioned on the sale of another property?', 'Select the sale condition.'),
    yn('conditions.additionalEarnestMoney', 'Will an additional earnest money deposit be due?', 'Select an additional-deposit option.'),
  ] },
  { id: 'deadlines', title: 'Contract deadlines', description: 'Unless the parties agree otherwise, times are 5:00 p.m. Mountain Time on each date.', questions: [
    { id: 'seller-date', type: 'date', label: 'Seller disclosure deadline', fieldPath: 'deadlines.sellerDisclosureDate', validation: required('Set the seller disclosure deadline.') },
    { id: 'inspection-date', type: 'date', label: 'Due diligence deadline', fieldPath: 'deadlines.dueDiligenceDate', visibleWhen: { match: 'all', conditions: [{ fieldPath: 'conditions.dueDiligence', operator: 'is_true' }] }, validation: required('Set the due diligence deadline.') },
    { id: 'financing-date', type: 'date', label: 'Financing and appraisal deadline', fieldPath: 'deadlines.financingAppraisalDate', visibleWhen: { match: 'any', conditions: [{ fieldPath: 'conditions.financing', operator: 'is_true' }, { fieldPath: 'conditions.appraisal', operator: 'is_true' }] }, validation: required('Set the financing and appraisal deadline.') },
    { id: 'settlement-date', type: 'date', label: 'Settlement deadline', fieldPath: 'deadlines.settlementDate', validation: required('Set the settlement deadline.') },
  ] },
  { id: 'settlement', title: 'Possession and charges', questions: [
    { id: 'possession', type: 'single_choice', label: 'When does the buyer take possession?', fieldPath: 'settlement.possession', validation: required('Choose when possession transfers.'), options: [
      { value: 'at_recording', label: 'At recording' }, { value: 'hours_after', label: 'Specified hours after recording' }, { value: 'days_after', label: 'Specified days after recording' },
    ] },
    { id: 'delay', type: 'number', label: 'Hours or days after recording', fieldPath: 'settlement.possessionDelay', visibleWhen: { match: 'all', conditions: [{ fieldPath: 'settlement.possession', operator: 'not_equals', value: 'at_recording' }, { fieldPath: 'settlement.possession', operator: 'not_equals', value: 'unselected' }] }, validation: { required: true, minimum: 1, maximum: 365, message: 'Enter a delay between 1 and 365.' } },
    { id: 'assessment-payer', type: 'single_choice', label: 'Who pays pre-settlement special assessments?', fieldPath: 'settlement.specialAssessmentPayer', validation: required('Select who pays special assessments.'), options: [
      { value: 'buyer', label: 'Buyer' }, { value: 'seller', label: 'Seller' }, { value: 'split', label: 'Split equally' },
    ] },
    { id: 'hoa-payer', type: 'single_choice', label: 'Who pays association transfer fees, if any?', fieldPath: 'settlement.hoaTransferFeePayer', validation: required('Select who pays association transfer fees.'), options: [
      { value: 'buyer', label: 'Buyer' }, { value: 'seller', label: 'Seller' }, { value: 'split', label: 'Split equally' },
    ] },
  ] },
  { id: 'disclosures', title: 'Seller disclosures', questions: [
    { id: 'seller-meth-statement', type: 'yes_no', label: 'Seller reports known current methamphetamine contamination', fieldPath: 'disclosures.sellerReportsCurrentMethContamination', readOnly: true, validation: required('The seller must answer the contamination question on the listing.') },
    { id: 'condition-status', type: 'single_choice', label: 'Seller property condition statement', fieldPath: 'disclosures.propertyConditionStatus', validation: required('Select the condition statement status.'), options: [
      { value: 'received', label: 'Received' }, { value: 'pending', label: 'Seller to deliver by disclosure deadline' },
    ] },
    { id: 'lead-status', type: 'single_choice', label: 'Lead-based paint packet', fieldPath: 'disclosures.leadPaintStatus', validation: required('Select the lead paint disclosure status.'), options: [
      { value: 'received', label: 'Signed packet, available reports and EPA pamphlet received' }, { value: 'built_1978_or_later', label: 'Built after 1977' }, { value: 'exempt', label: 'Other federal exemption applies' },
    ] },
    { id: 'lead-inspection', type: 'single_choice', label: 'Buyer’s lead paint inspection opportunity', fieldPath: 'disclosures.leadInspectionSelection', visibleWhen: { match: 'all', conditions: [{ fieldPath: 'disclosures.leadPaintStatus', operator: 'equals', value: 'received' }] }, validation: required('Select the buyer’s lead inspection option.'), options: [
      { value: 'ten_days', label: '10 days for a lead inspection or risk assessment' }, { value: 'waived', label: 'Buyer waives the inspection opportunity' }, { value: 'other_period', label: 'Different period agreed in writing' },
    ] },
    { id: 'lead-inspection-days', type: 'number', label: 'Agreed lead inspection days', fieldPath: 'disclosures.leadInspectionDays', visibleWhen: { match: 'all', conditions: [{ fieldPath: 'disclosures.leadInspectionSelection', operator: 'equals', value: 'other_period' }] }, validation: { required: true, minimum: 1, maximum: 60, message: 'Enter 1 to 60 agreed days.' } },
    { id: 'hoa-status', type: 'single_choice', label: 'Association documents', fieldPath: 'disclosures.hoaDocumentsStatus', validation: required('Select the association document status.'), options: [
      { value: 'received', label: 'Received' }, { value: 'pending', label: 'To be provided before closing' }, { value: 'not_applicable', label: 'No association' },
    ] },
    { id: 'meth-acknowledgement', type: 'acknowledgement', label: 'I have reviewed the seller’s statement about known current methamphetamine contamination.', fieldPath: 'disclosures.methamphetamineContaminationAcknowledged', validation: required('Review and acknowledge the seller statement.') },
  ] },
  { id: 'additional', title: 'Additional terms', questions: [
    { id: 'additional-terms', type: 'textarea', label: 'Party-provided additional terms', fieldPath: 'additionalTerms', helpText: 'Ask a Utah attorney to review any new legal language.' },
  ] },
  { id: 'delivery', title: 'Offer delivery and review', questions: [
    { id: 'expiration', type: 'date_time', label: 'Offer expires', fieldPath: 'delivery.expiresAt', validation: required('Set a future expiration date and time.') },
    { id: 'electronic', type: 'acknowledgement', label: 'I agree to electronic delivery and signatures for this offer.', fieldPath: 'delivery.electronicDeliveryAuthorized', validation: required('Electronic delivery consent is required.') },
  ] },
];
