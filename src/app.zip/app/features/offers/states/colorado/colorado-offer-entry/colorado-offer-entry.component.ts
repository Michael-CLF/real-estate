import { Component } from '@angular/core';

@Component({
  selector: 'app-colorado-offer-entry',
  imports: [],
  templateUrl: './colorado-offer-entry.component.html',
  styleUrl: './colorado-offer-entry.component.scss',
})
export class ColoradoOfferEntryComponent {

}
