import { Injectable } from '@angular/core';
import {
    collection,
    getDocs,
    query,
    where
} from 'firebase/firestore';
import {
    defer,
    map,
    Observable
} from 'rxjs';

import { firestore } from '../../../infrastructure/firebase/firebase';
import {
    ListingSearchFilters,
    ListingSearchResult,
    MarketplaceListingSummary
} from '../models/listing-search-filters.model';
import {
    MarketplaceListing
} from '../models/marketplace-listing.model';
import {
    MarketplaceListingRepository
} from './marketplace-listing.repository';

const STATE_NAME_BY_ABBREVIATION:
    Readonly<Record<string, string>> = {
    AL: 'Alabama',
    AK: 'Alaska',
    AZ: 'Arizona',
    AR: 'Arkansas',
    CA: 'California',
    CO: 'Colorado',
    CT: 'Connecticut',
    DE: 'Delaware',
    FL: 'Florida',
    GA: 'Georgia',
    HI: 'Hawaii',
    ID: 'Idaho',
    IL: 'Illinois',
    IN: 'Indiana',
    IA: 'Iowa',
    KS: 'Kansas',
    KY: 'Kentucky',
    LA: 'Louisiana',
    ME: 'Maine',
    MD: 'Maryland',
    MA: 'Massachusetts',
    MI: 'Michigan',
    MN: 'Minnesota',
    MS: 'Mississippi',
    MO: 'Missouri',
    MT: 'Montana',
    NE: 'Nebraska',
    NV: 'Nevada',
    NH: 'New Hampshire',
    NJ: 'New Jersey',
    NM: 'New Mexico',
    NY: 'New York',
    NC: 'North Carolina',
    ND: 'North Dakota',
    OH: 'Ohio',
    OK: 'Oklahoma',
    OR: 'Oregon',
    PA: 'Pennsylvania',
    RI: 'Rhode Island',
    SC: 'South Carolina',
    SD: 'South Dakota',
    TN: 'Tennessee',
    TX: 'Texas',
    UT: 'Utah',
    VT: 'Vermont',
    VA: 'Virginia',
    WA: 'Washington',
    WV: 'West Virginia',
    WI: 'Wisconsin',
    WY: 'Wyoming',
    DC: 'District of Columbia'
};

@Injectable()
export class FirestoreMarketplaceListingRepository
    extends MarketplaceListingRepository {

    override searchListings(
        filters: ListingSearchFilters
    ): Observable<ListingSearchResult> {
        return this.loadActiveListings().pipe(
            map(listings =>
                this.createSearchResult(
                    listings,
                    filters
                )
            )
        );
    }

    override getListingById(
        listingUid: string
    ): Observable<MarketplaceListing | null> {
        return this.loadActiveListings().pipe(
            map(listings =>
                listings.find(
                    listing => listing.uid === listingUid
                ) ?? null
            )
        );
    }

    override getListingsBySellerId(
        sellerUid: string
    ): Observable<MarketplaceListing[]> {
        const listingsReference = collection(
            firestore,
            'listings'
        );

        const sellerListingsQuery = query(
            listingsReference,
            where('sellerUid', '==', sellerUid)
        );

        return defer(() =>
            getDocs(sellerListingsQuery)
        ).pipe(
            map(snapshot =>
                snapshot.docs
                    .map(document =>
                        this.mapFirestoreListing(
                            document.id,
                            document.data()
                        )
                    )
                    .filter(
                        (
                            listing
                        ): listing is MarketplaceListing =>
                            listing !== null
                    )
            )
        );
    }

    override getFeaturedListings(
        limit: number
    ): Observable<MarketplaceListingSummary[]> {
        return this.loadActiveListings().pipe(
            map(listings =>
                listings
                    .filter(listing =>
                        this.isFeaturedListing(listing)
                    )
                    .sort(
                        (
                            firstListing,
                            secondListing
                        ) =>
                            (
                                secondListing
                                    .publishedAt
                                    ?.getTime() ??
                                secondListing
                                    .createdAt
                                    .getTime()
                            ) -
                            (
                                firstListing
                                    .publishedAt
                                    ?.getTime() ??
                                firstListing
                                    .createdAt
                                    .getTime()
                            )
                    )
                    .slice(
                        0,
                        Math.max(limit, 0)
                    )
                    .map(listing =>
                        this.toListingSummary(listing)
                    )
            )
        );
    }
    private loadActiveListings():
        Observable<MarketplaceListing[]> {
        const listingsReference = collection(
            firestore,
            'listings'
        );

        const activeListingsQuery = query(
            listingsReference,
            where(
                'status',
                'in',
                [
                    'active',
                    'under_contract',
                    'sold'
                ]
            )
        );

        return defer(() =>
            getDocs(activeListingsQuery)
        ).pipe(
            map(snapshot =>
                snapshot.docs
                    .map(document =>
                        this.mapFirestoreListing(
                            document.id,
                            document.data()
                        )
                    )
                    .filter(
                        (
                            listing
                        ): listing is MarketplaceListing =>
                            listing !== null
                    )
            )
        );
    }

    private createSearchResult(
        listings: MarketplaceListing[],
        filters: ListingSearchFilters
    ): ListingSearchResult {
        const page = Math.max(
            filters.page ?? 1,
            1
        );

        const pageSize = Math.max(
            filters.pageSize ?? 12,
            1
        );

        let filteredListings = [...listings];

        if (filters.listingStatuses?.length) {
            filteredListings =
                filteredListings.filter(
                    listing =>
                        filters.listingStatuses?.includes(
                            listing.status
                        )
                );
        }

        if (filters.searchTerm) {
            const searchTerm =
                filters.searchTerm.trim().toLowerCase();

            filteredListings =
                filteredListings.filter(listing => {
                    const searchableText = [
                        listing.title,
                        listing.address.addressLine1,
                        listing.address.city,
                        listing.address.state,
                        listing.address.stateAbbreviation,
                        listing.address.stateSlug,
                        listing.address.postalCode,
                        listing.address.county ?? ''
                    ]
                        .join(' ')
                        .toLowerCase();

                    return searchableText.includes(searchTerm);
                });
        }

        if (filters.stateSlug) {
            filteredListings =
                filteredListings.filter(
                    listing =>
                        listing.address.stateSlug ===
                        filters.stateSlug
                );
        }

        if (filters.city) {
            const city =
                filters.city.trim().toLowerCase();

            filteredListings =
                filteredListings.filter(
                    listing =>
                        listing.address.city
                            .trim()
                            .toLowerCase() === city
                );
        }

        if (filters.postalCode) {
            const postalCode =
                filters.postalCode.trim();

            filteredListings =
                filteredListings.filter(
                    listing =>
                        listing.address.postalCode ===
                        postalCode
                );
        }

        if (filters.propertyTypes?.length) {
            filteredListings =
                filteredListings.filter(
                    listing =>
                        filters.propertyTypes?.includes(
                            listing.propertyType
                        )
                );
        }

        if (filters.minimumPrice !== undefined) {
            filteredListings =
                filteredListings.filter(
                    listing =>
                        listing.price >=
                        filters.minimumPrice!
                );
        }

        if (filters.maximumPrice !== undefined) {
            filteredListings =
                filteredListings.filter(
                    listing =>
                        listing.price <=
                        filters.maximumPrice!
                );
        }

        if (filters.minimumBedrooms !== undefined) {
            filteredListings =
                filteredListings.filter(
                    listing =>
                        (listing.bedrooms ?? 0) >=
                        filters.minimumBedrooms!
                );
        }

        if (filters.minimumBathrooms !== undefined) {
            filteredListings =
                filteredListings.filter(
                    listing =>
                        (listing.bathrooms ?? 0) >=
                        filters.minimumBathrooms!
                );
        }

        if (filters.minimumSquareFeet !== undefined) {
            filteredListings =
                filteredListings.filter(
                    listing =>
                        (listing.squareFeet ?? 0) >=
                        filters.minimumSquareFeet!
                );
        }

        filteredListings = this.sortListings(
            filteredListings,
            filters.sort ?? 'newest'
        );

        const totalCount =
            filteredListings.length;

        const totalPages = Math.max(
            Math.ceil(totalCount / pageSize),
            1
        );

        const safePage = Math.min(
            page,
            totalPages
        );

        const startIndex =
            (safePage - 1) * pageSize;

        return {
            listings: filteredListings
                .slice(
                    startIndex,
                    startIndex + pageSize
                )
                .map(listing =>
                    this.toListingSummary(listing)
                ),

            totalCount,
            page: safePage,
            pageSize,
            totalPages
        };
    }

    private mapFirestoreListing(
        documentId: string,
        data: Record<string, unknown>
    ): MarketplaceListing | null {
        const propertyDetails =
            this.readRecord(
                data['propertyDetails']
            );

        const hoaData =
            this.readRecord(
                propertyDetails?.['hoa']
            ) ??
            this.readRecord(
                data['hoa']
            );

        const parcelAndTaxesData =
            this.readRecord(
                data['parcelAndTaxes'],
            );

        const enhancements =
            this.readEnhancements(
                data['enhancements']
            );

        const schools =
            this.readSchools(
                data['schools']
            );

        const city = this.readString(
            data['city']
        );

        const state = this.readString(
            data['state']
        );

        const postalCode =
            this.readString(
                data['zipCode']
            );

        if (
            !city ||
            !state ||
            !postalCode
        ) {
            return null;
        }

        const addressLine1 =
            this.readString(
                data['addressLine1']
            );

        const stateAbbreviation =
            this.getStateAbbreviation(state);

        const photos =
            this.mapFirestorePhotos(
                documentId,
                data['photos'],
                data['photoUrls']
            );

        const primaryPhotoUrl =
            this.readString(
                data['primaryPhotoUrl']
            ) ||
            this.readString(
                data['featuredPhotoUrl']
            ) ||
            this.readString(
                data['photoUrls'],
                0
            );

        const latitude =
            this.readNumber(
                data['latitude']
            ) ?? 0;

        const longitude =
            this.readNumber(
                data['longitude']
            ) ?? 0;

        const lotSize =
            this.readNumber(
                data['lotSize']
            );

        const storedLotSizeUnit =
            this.readString(
                data['lotSizeUnit']
            );

        const lotSizeUnit:
            NonNullable<
                MarketplaceListing['lotSizeUnit']
            > =
            storedLotSizeUnit === 'square_feet'
                ? 'square_feet'
                : 'acres';

        return {
            uid:
                this.readString(data['Uid']) ||
                documentId,

            sellerUid:
                this.readString(
                    data['sellerUid']
                ),

            status:
                data['status'] as MarketplaceListing['status'],

            pendingOfferCount:
                Math.max(
                    0,
                    this.readNumber(
                        data['pendingOfferCount']
                    ) ?? 0
                ),

            propertyType:
                data['propertyType'] as
                MarketplaceListing['propertyType'],

            title:
                this.readString(
                    data['title']
                ) ||
                addressLine1 ||
                `Home in ${city}`,

            description:
                this.readString(
                    data['description']
                ),

            price:
                this.readNumber(
                    data['listPrice']
                ) ?? 0,

            featuredListing:
                data['featuredListing'] === true,

            bedrooms:
                this.readNumber(
                    data['bedrooms']
                ),
            bathrooms:
                this.readNumber(
                    data['bathrooms']
                ),

            squareFeet:
                this.readNumber(
                    data['squareFeet']
                ),

            lotSize,

            lotSizeUnit:
                lotSize !== undefined
                    ? lotSizeUnit
                    : undefined,

            lotSizeAcres:
                lotSize !== undefined &&
                    lotSizeUnit === 'acres'
                    ? lotSize
                    : undefined,

            yearBuilt:
                this.readNumber(
                    data['yearBuilt']
                ),

            sellerStatements:
                data['sellerStatements'] && typeof data['sellerStatements'] === 'object'
                    ? {
                        ownersAssociationApplies: (data['sellerStatements'] as Record<string, unknown>)['ownersAssociationApplies'] as boolean | null | undefined,
                        leadBasedPaintApplies: (data['sellerStatements'] as Record<string, unknown>)['leadBasedPaintApplies'] as boolean | null | undefined,
                    }
                    : undefined,

            annualPropertyTax:
                this.readNumber(
                    parcelAndTaxesData?.[
                    'annualPropertyTax'
                    ],
                ) ??
                this.readNumber(
                    data['annualPropertyTax'],
                ),

            annualHomeownersInsurance:
                this.readNumber(
                    data[
                    'annualHomeownersInsurance'
                    ],
                ),

            hoa: hoaData
                ? hoaData['hasHoa'] === true
                    ? {
                        hasHoa: true,

                        feeAmount:
                            this.readNumber(
                                hoaData['feeAmount']
                            ),

                        feeFrequency:
                            this.readString(
                                hoaData['feeFrequency']
                            ) as NonNullable<
                                MarketplaceListing['hoa']
                            >['feeFrequency'],

                        includedItems:
                            Array.isArray(
                                hoaData['includedItems']
                            )
                                ? hoaData['includedItems'] as NonNullable<
                                    MarketplaceListing['hoa']
                                >['includedItems']
                                : []
                    }
                    : {
                        hasHoa: false,
                        includedItems: []
                    }
                : undefined,

            enhancements,

            schools,

            address: {
                addressLine1,

                addressLine2:
                    this.readString(
                        data['addressLine2']
                    ) || undefined,

                city,
                state:
                    this.getStateName(state),

                stateAbbreviation,

                stateSlug:
                    this.createStateSlug(state),

                postalCode,

                county:
                    this.readString(
                        data['county']
                    ) || undefined
            },

            location: {
                latitude,
                longitude,

                geohash:
                    this.readString(
                        data['geohash']
                    ) || undefined
            },

            photos,

            featuredPhotoUrl:
                primaryPhotoUrl || undefined,

            photoCount:
                photos.length ||
                (
                    Array.isArray(
                        data['photoUrls']
                    )
                        ? data['photoUrls'].length
                        : 0
                ),

            favoriteCount:
                this.readNumber(
                    data['favorites']
                ) ??
                this.readNumber(
                    data['favoriteCount']
                ) ??
                0,

            viewCount:
                this.readNumber(
                    data['views']
                ) ??
                this.readNumber(
                    data['viewCount']
                ) ??
                0,

            inquiryCount:
                this.readNumber(
                    data['inquiries']
                ) ??
                this.readNumber(
                    data['inquiryCount']
                ) ??
                0,

            publishedAt:
                this.toDate(
                    data['publishedAt']
                ),

            createdAt:
                this.toDate(
                    data['createdAt']
                ) ?? new Date(),

            updatedAt:
                this.toDate(
                    data['updatedAt']
                ) ?? new Date()
        };
    }

    private mapFirestorePhotos(
        listingUid: string,
        photosValue: unknown,
        photoUrlsValue: unknown
    ): MarketplaceListing['photos'] {
        const mappedPhotos =
            Array.isArray(photosValue)
                ? photosValue
                    .map(
                        (
                            photoValue,
                            photoIndex
                        ) => {
                            const photo =
                                this.readRecord(
                                    photoValue
                                );

                            if (!photo) {
                                return null;
                            }

                            const url =
                                this.readString(
                                    photo['fullImageUrl']
                                ) ||
                                this.readString(
                                    photo['url']
                                ) ||
                                this.readString(
                                    photo['thumbnailUrl']
                                );

                            if (!url) {
                                return null;
                            }

                            return {
                                id:
                                    this.readString(
                                        photo['id']
                                    ) ||
                                    `${listingUid}-${photoIndex}`,

                                listingId:
                                    listingUid,

                                url,

                                storagePath:
                                    this.readString(
                                        photo['storagePath']
                                    ),

                                altText:
                                    this.readString(
                                        photo['altText']
                                    ) ||
                                    this.readString(
                                        photo['originalFileName']
                                    ) ||
                                    `Property photograph ${photoIndex + 1
                                    }`,

                                sortOrder:
                                    this.readNumber(
                                        photo['sortOrder']
                                    ) ??
                                    photoIndex,

                                isFeatured:
                                    photo['isPrimary'] === true ||
                                    photo['isFeatured'] === true,

                                createdAt:
                                    this.toDate(
                                        photo['createdAt']
                                    ) ??
                                    new Date()
                            };
                        }
                    )
                    .filter(
                        (
                            photo
                        ): photo is MarketplaceListing['photos'][number] =>
                            photo !== null
                    )
                : [];

        if (mappedPhotos.length > 0) {
            return mappedPhotos.sort(
                (
                    firstPhoto,
                    secondPhoto
                ) =>
                    firstPhoto.sortOrder -
                    secondPhoto.sortOrder
            );
        }

        if (!Array.isArray(photoUrlsValue)) {
            return [];
        }

        return photoUrlsValue
            .map(
                (
                    photoUrl,
                    photoIndex
                ) => {
                    const url =
                        this.readString(
                            photoUrl
                        );

                    if (!url) {
                        return null;
                    }

                    return {
                        id:
                            `${listingUid}-${photoIndex}`,

                        listingId:
                            listingUid,

                        url,

                        storagePath: '',

                        altText:
                            `Property photograph ${photoIndex + 1
                            }`,

                        sortOrder:
                            photoIndex,

                        isFeatured:
                            photoIndex === 0,

                        createdAt:
                            new Date()
                    };
                }
            )
            .filter(
                (
                    photo
                ): photo is MarketplaceListing['photos'][number] =>
                    photo !== null
            );
    }

    private readSchools(
        value: unknown
    ): MarketplaceListing['schools'] {
        const data =
            this.readRecord(value);

        if (!data) {
            return undefined;
        }

        const readSchool = (
            key:
                | 'elementarySchool'
                | 'middleSchool'
                | 'highSchool'
        ) => {
            const schoolData =
                this.readRecord(
                    data[key]
                );

            if (!schoolData) {
                return undefined;
            }

            const name =
                this.readString(
                    schoolData['name']
                );

            if (!name) {
                return undefined;
            }

            const district =
                this.readString(
                    schoolData['district']
                );

            const grades =
                this.readString(
                    schoolData['grades']
                );

            const schoolType =
                this.readString(
                    schoolData['schoolType']
                ) as NonNullable<
                    NonNullable<
                        MarketplaceListing['schools']
                    >['elementarySchool']
                >['schoolType'];

            const distanceMiles =
                this.readNumber(
                    schoolData['distanceMiles']
                );

            return {
                name,

                schoolType:
                    schoolType || 'public',

                ...(district
                    ? {
                        district
                    }
                    : {}),

                ...(grades
                    ? {
                        grades
                    }
                    : {}),

                ...(distanceMiles !== undefined
                    ? {
                        distanceMiles
                    }
                    : {})
            };
        };

        const districtName =
            this.readString(
                data['districtName']
            );

        const elementarySchool =
            readSchool(
                'elementarySchool'
            );

        const middleSchool =
            readSchool(
                'middleSchool'
            );

        const highSchool =
            readSchool(
                'highSchool'
            );

        if (
            !districtName &&
            !elementarySchool &&
            !middleSchool &&
            !highSchool
        ) {
            return undefined;
        }

        return {
            ...(districtName
                ? {
                    districtName
                }
                : {}),

            ...(elementarySchool
                ? {
                    elementarySchool
                }
                : {}),

            ...(middleSchool
                ? {
                    middleSchool
                }
                : {}),

            ...(highSchool
                ? {
                    highSchool
                }
                : {}),

            assignedSchoolsVerified:
                data['assignedSchoolsVerified'] === true
        };
    }

    private readEnhancements(
        value: unknown
    ): MarketplaceListing['enhancements'] {
        const data = this.readRecord(value);

        if (!data) {
            return undefined;
        }

        const readStringArray = (
            key: string
        ): string[] | undefined => {
            const candidate = data[key];

            if (!Array.isArray(candidate)) {
                return undefined;
            }

            const values = candidate.filter(
                (item): item is string =>
                    typeof item === 'string' &&
                    item.trim().length > 0
            );

            return values.length > 0
                ? values
                : undefined;
        };

        const enhancements = {
            construction: readStringArray('construction'),
            interior: readStringArray('interior'),
            kitchen: readStringArray('kitchen'),
            bedroomsBathrooms:
                readStringArray('bedroomsBathrooms'),
            parkingStorage:
                readStringArray('parkingStorage'),
            outdoorLiving:
                readStringArray('outdoorLiving'),
            systemsUtilities:
                readStringArray('systemsUtilities'),
            technologySecurity:
                readStringArray('technologySecurity'),
            accessibility:
                readStringArray('accessibility'),
            communityAmenities:
                readStringArray('communityAmenities')
        };

        return Object.values(enhancements).some(Boolean)
            ? enhancements
            : undefined;
    }

    private sortListings(
        listings: MarketplaceListing[],
        sort: ListingSearchFilters['sort']
    ): MarketplaceListing[] {
        const sortedListings = [...listings];

        switch (sort) {
            case 'price_low_to_high':
                return sortedListings.sort(
                    (firstListing, secondListing) =>
                        firstListing.price -
                        secondListing.price
                );

            case 'price_high_to_low':
                return sortedListings.sort(
                    (firstListing, secondListing) =>
                        secondListing.price -
                        firstListing.price
                );

            case 'bedrooms_high_to_low':
                return sortedListings.sort(
                    (firstListing, secondListing) =>
                        (secondListing.bedrooms ?? 0) -
                        (firstListing.bedrooms ?? 0)
                );

            case 'square_feet_high_to_low':
                return sortedListings.sort(
                    (firstListing, secondListing) =>
                        (secondListing.squareFeet ?? 0) -
                        (firstListing.squareFeet ?? 0)
                );

            case 'newest':
            default:
                return sortedListings.sort(
                    (firstListing, secondListing) =>
                        (
                            secondListing.publishedAt?.getTime() ??
                            secondListing.createdAt.getTime()
                        ) -
                        (
                            firstListing.publishedAt?.getTime() ??
                            firstListing.createdAt.getTime()
                        )
                );
        }
    }

    private toListingSummary(
        listing: MarketplaceListing
    ): MarketplaceListingSummary {
        return {
            id: listing.uid,
            sellerUid: listing.sellerUid,

            title: listing.title,
            propertyType: listing.propertyType,
            status: listing.status,
            pendingOfferCount:
                listing.pendingOfferCount,

            price: listing.price,
            originalPrice: listing.originalPrice,
            featuredListing: listing.featuredListing,

            bedrooms: listing.bedrooms,
            bathrooms: listing.bathrooms,
            squareFeet: listing.squareFeet,

            city: listing.address.city,

            stateAbbreviation:
                listing.address.stateAbbreviation,

            postalCode:
                listing.address.postalCode,

            featuredPhotoUrl:
                listing.featuredPhotoUrl,

            favoriteCount:
                listing.favoriteCount,

            viewCount:
                listing.viewCount,

            inquiryCount:
                listing.inquiryCount,

            publishedAt:
                listing.publishedAt
        };
    }

    private isFeaturedListing(
        listing: MarketplaceListing
    ): boolean {
        return (
            listing.status === 'active' &&
            listing.featuredListing === true
        );
    }

    private readRecord(
        value: unknown
    ): Record<string, unknown> | undefined {
        return value !== null &&
            typeof value === 'object' &&
            !Array.isArray(value)
            ? value as Record<string, unknown>
            : undefined;
    }

    private readString(
        value: unknown,
        arrayIndex?: number
    ): string {
        if (
            arrayIndex !== undefined &&
            Array.isArray(value)
        ) {
            const arrayValue =
                value[arrayIndex];

            return typeof arrayValue === 'string'
                ? arrayValue.trim()
                : '';
        }

        return typeof value === 'string'
            ? value.trim()
            : '';
    }

    private readNumber(
        value: unknown
    ): number | undefined {
        return typeof value === 'number' &&
            Number.isFinite(value)
            ? value
            : undefined;
    }

    private toDate(
        value: unknown
    ): Date | undefined {
        if (value instanceof Date) {
            return value;
        }

        if (
            value &&
            typeof value === 'object' &&
            'toDate' in value &&
            typeof (
                value as {
                    toDate?: unknown;
                }
            ).toDate === 'function'
        ) {
            return (
                value as {
                    toDate(): Date;
                }
            ).toDate();
        }

        if (
            typeof value === 'string' ||
            typeof value === 'number'
        ) {
            const date = new Date(value);

            return Number.isNaN(
                date.getTime()
            )
                ? undefined
                : date;
        }

        return undefined;
    }

    private getStateAbbreviation(
        state: string
    ): string {
        const normalizedState = state.trim();
        const possibleAbbreviation =
            normalizedState.toUpperCase();

        if (
            STATE_NAME_BY_ABBREVIATION[
            possibleAbbreviation
            ]
        ) {
            return possibleAbbreviation;
        }

        const matchingState = Object.entries(
            STATE_NAME_BY_ABBREVIATION
        ).find(
            ([, stateName]) =>
                stateName.toLowerCase() ===
                normalizedState.toLowerCase()
        );

        return matchingState?.[0] ?? normalizedState;
    }

    private getStateName(
        state: string
    ): string {
        const normalizedState = state.trim();
        const stateName =
            STATE_NAME_BY_ABBREVIATION[
            normalizedState.toUpperCase()
            ];

        if (stateName) {
            return stateName;
        }

        return Object.values(
            STATE_NAME_BY_ABBREVIATION
        ).find(
            candidate =>
                candidate.toLowerCase() ===
                normalizedState.toLowerCase()
        ) ?? normalizedState;
    }

    private createStateSlug(
        state: string
    ): string {
        const stateName =
            this.getStateName(state);

        return stateName
            .trim()
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/^-|-$/g, '');
    }
}