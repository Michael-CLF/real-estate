import {
  ChangeDetectionStrategy,
  Component,
  computed,
  effect,
  input,
  output,
  signal,
} from '@angular/core';

import type {
  OfferParty,
} from '../../../../../core/domains/offers/models/offer-party.model';

import type {
  OfferPropertySnapshot,
} from '../../../../../core/domains/offers/models/offer-terms.model';

import type {
  OfferValidationIssue,
} from '../../../../../core/domains/offers/models/offer-validation.model';

import type {
  TexasContractDefinition,
} from '../../../../../core/domains/offers/state-contracts/texas/models/texas-contract-type.model';

import type {
  TexasOfferTerms,
} from '../../../../../core/domains/offers/state-contracts/texas/models/texas-offer-terms.model';

import {
  OfferWizardShellComponent,
} from '../../../engine/offer-wizard-shell/offer-wizard-shell.component';

import type {
  OfferFieldValueChange,
} from '../../../engine/offer-wizard-shell/offer-wizard-shell.component';

import type {
  OfferDocumentSelection,
} from '../../../engine/question-renderer/question-renderer.component';

import {
  TexasContractSelectionComponent,
} from '../contract-selection/texas-contract-selection.component';

import type {
  TexasContractSelection,
} from '../contract-selection/texas-contract-selection.component';

import {
  updateTexasOfferTerms,
} from '../services/texas-offer-terms-updater';

import {
  TEXAS_OFFER_PACKAGE,
} from '../texas-offer-package';


export interface TexasOfferDraftChange {
  readonly terms: TexasOfferTerms;
  readonly expiresAt: string;
}


@Component({
  selector: 'app-offer-wizard',
  standalone: true,

  imports: [
    OfferWizardShellComponent,
    TexasContractSelectionComponent,
  ],

  templateUrl:
    './offer-wizard.component.html',

  styleUrl:
    './offer-wizard.component.scss',

  changeDetection:
    ChangeDetectionStrategy.OnPush,
})
export class OfferWizardComponent {
  readonly property =
    input.required<OfferPropertySnapshot>();

  readonly buyers =
    input<readonly OfferParty[]>([]);

  readonly sellers =
    input<readonly OfferParty[]>([]);

  readonly expiresAt = input.required<string>();
  readonly timeZone = input.required<string>();

  readonly initialTerms =
    input<TexasOfferTerms | null>(null);

  readonly saving = input(false);
  readonly submitting = input(false);

  readonly draftChanged =
    output<TexasOfferDraftChange>();

  readonly documentSelected =
    output<OfferDocumentSelection>();

  readonly contractSelected =
    output<TexasContractDefinition>();

  readonly submitRequested =
    output<TexasOfferTerms>();

  readonly returnToListingRequested =
    output<void>();

  protected readonly terms =
    signal<TexasOfferTerms | null>(null);

  protected readonly submissionAttempted =
    signal(false);

  private initialTermsApplied = false;

  protected readonly busy = computed(
    () => this.saving() || this.submitting()
  );

  protected readonly contractDefinition = computed(
    () => {
      const terms = this.terms();

      return terms
        ? TEXAS_OFFER_PACKAGE.contracts[
            terms.contractType
          ]
        : null;
    }
  );

  protected readonly sections = computed(
    () => {
      const terms = this.terms();

      return terms
        ? TEXAS_OFFER_PACKAGE.getSections(terms)
        : [];
    }
  );

  protected readonly validationIssues = computed<
    readonly OfferValidationIssue[]
  >(
    () => {
      const terms = this.terms();

      if (!terms) {
        return [];
      }

      const result = TEXAS_OFFER_PACKAGE.validate(
        terms,
        this.buyers(),
        this.sellers(),
        {
          mode: this.submissionAttempted()
            ? 'submit'
            : 'draft',
          currentDateTime: new Date(),
        }
      );

      return [
        ...result.errors,
        ...result.warnings,
      ];
    }
  );


  constructor() {
    effect(() => {
      const initialTerms = this.initialTerms();

      if (
        !this.initialTermsApplied &&
        initialTerms
      ) {
        this.terms.set(initialTerms);
        this.initialTermsApplied = true;
      }
    });
  }


  protected onContractSelected(
    selection: TexasContractSelection
  ): void {
    if (this.busy()) {
      return;
    }

    const terms =
      TEXAS_OFFER_PACKAGE.createInitialTerms({
        contractType:
          selection.definition.contractType,
        property: this.property(),
        expiresAt: this.expiresAt(),
        timeZone: this.timeZone(),
      });

    this.terms.set(terms);
    this.submissionAttempted.set(false);

    this.contractSelected.emit(
      selection.definition
    );

    this.emitDraftChange(terms);
  }


  protected onFieldValueChange(
    change: OfferFieldValueChange
  ): void {
    const currentTerms = this.terms();

    if (!currentTerms || this.busy()) {
      return;
    }

    const updatedTerms =
      updateTexasOfferTerms(
        currentTerms,
        change.fieldPath,
        change.value
      );

    this.terms.set(updatedTerms);
    this.submissionAttempted.set(false);
    this.emitDraftChange(updatedTerms);
  }


  /*
   * Called by the persistence container after an uploaded
   * document has been registered and a document UID exists.
   */
  applyDocumentUid(
    fieldPath: string,
    documentUid: string
  ): void {
    const currentTerms = this.terms();

    if (!currentTerms) {
      return;
    }

    const updatedTerms =
      updateTexasOfferTerms(
        currentTerms,
        fieldPath,
        documentUid
      );

    this.terms.set(updatedTerms);
    this.emitDraftChange(updatedTerms);
  }


  protected onSubmitRequested(): void {
    const currentTerms = this.terms();

    if (!currentTerms || this.busy()) {
      return;
    }

    this.submissionAttempted.set(true);

    const result = TEXAS_OFFER_PACKAGE.validate(
      currentTerms,
      this.buyers(),
      this.sellers(),
      {
        mode: 'submit',
        currentDateTime: new Date(),
      }
    );

    if (!result.valid) {
      return;
    }

    this.submitRequested.emit(currentTerms);
  }


  private emitDraftChange(
    terms: TexasOfferTerms
  ): void {
    this.draftChanged.emit({
      terms,
      expiresAt: terms.delivery.expiresAt,
    });
  }
}
