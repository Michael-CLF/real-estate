import { record, text, money, integer, bool, choice } from '../draft-term-values';
import type { SanitizeDraftTermsInput } from '../state-contract-package';
import type { WisconsinOfferTermsDocument } from './wisconsin-offer-terms.document';
export function sanitizeWisconsinDraftTerms(input: SanitizeDraftTermsInput<WisconsinOfferTermsDocument>): WisconsinOfferTermsDocument {
  const request = record(input.requestedTerms); const purchase = record(request['purchase']); const deadlines = record(request['deadlines']);
  const conditions = record(request['conditions']); const items = record(request['propertyItems']); const settlement = record(request['settlement']);
  const disclosures = record(request['disclosures']); const delivery = record(request['delivery']);
  const sanitized: WisconsinOfferTermsDocument = {
    ...input.currentTerms, // Preserve state, contract type, and immutable property snapshot.
    legalDescription: input.currentTerms.legalDescription, // Seller-provided listing snapshot; buyers cannot replace it.
    purchase: { purchasePriceInCents: money(purchase['purchasePriceInCents']), earnestMoneyInCents: money(purchase['earnestMoneyInCents']), additionalEarnestMoneyInCents: money(purchase['additionalEarnestMoneyInCents']), earnestMoneyHolder: text(purchase['earnestMoneyHolder'], 300), earnestMoneyDueDays: integer(purchase['earnestMoneyDueDays']), financingType: choice(purchase['financingType'], ['unselected', 'cash', 'conventional', 'fha', 'va', 'usda'] as const, 'unselected'), loanAmountInCents: money(purchase['loanAmountInCents']), sellerConcessionsInCents: money(purchase['sellerConcessionsInCents']) },
    deadlines: { sellerDisclosureDate: text(deadlines['sellerDisclosureDate'], 10), dueDiligenceDate: text(deadlines['dueDiligenceDate'], 10), financingAppraisalDate: text(deadlines['financingAppraisalDate'], 10), settlementDate: text(deadlines['settlementDate'], 10) },
    conditions: { dueDiligence: bool(conditions['dueDiligence']), appraisal: bool(conditions['appraisal']), financing: bool(conditions['financing']), saleOfBuyersProperty: bool(conditions['saleOfBuyersProperty']), additionalEarnestMoney: bool(conditions['additionalEarnestMoney']) },
    propertyItems: { included: text(items['included'], 3000), excluded: text(items['excluded'], 3000), fixturesIncluded: bool(items['fixturesIncluded']), leasedItemsDescription: text(items['leasedItemsDescription'], 2000) },
    settlement: { possession: choice(settlement['possession'], ['unselected', 'at_recording', 'hours_after', 'days_after'] as const, 'unselected'), possessionDelay: integer(settlement['possessionDelay']), specialAssessmentPayer: choice(settlement['specialAssessmentPayer'], ['unselected', 'buyer', 'seller', 'split'] as const, 'unselected'), hoaTransferFeePayer: choice(settlement['hoaTransferFeePayer'], ['unselected', 'buyer', 'seller', 'split'] as const, 'unselected') },
    disclosures: { sellerReportsExistingLeases: input.currentTerms.disclosures.sellerReportsExistingLeases, propertyConditionStatus: choice(disclosures['propertyConditionStatus'], ['unselected', 'received', 'pending'] as const, 'unselected'), leadPaintStatus: choice(disclosures['leadPaintStatus'], ['unselected', 'received', 'built_1978_or_later', 'exempt'] as const, 'unselected'), leadInspectionSelection: choice(disclosures['leadInspectionSelection'], ['unselected', 'ten_days', 'waived', 'other_period'] as const, 'unselected'), leadInspectionDays: integer(disclosures['leadInspectionDays']), hoaDocumentsStatus: choice(disclosures['hoaDocumentsStatus'], ['unselected', 'received', 'pending', 'not_applicable'] as const, 'unselected'), leaseStatementAcknowledged: bool(disclosures['leaseStatementAcknowledged']) },
    additionalTerms: text(request['additionalTerms'], 5000),
    delivery: { expiresAt: text(delivery['expiresAt'], 40), timeZone: 'America/Chicago', electronicDeliveryAuthorized: bool(delivery['electronicDeliveryAuthorized']) },
  };

  // Save-draft uses the trusted current version, never client-supplied terms,
  // as the source of statements belonging to the buyer.
  if (input.initiatedBy === 'seller') {
    return {
      ...sanitized,
      purchase: {
        ...sanitized.purchase,
        earnestMoneyInCents: input.currentTerms.purchase.earnestMoneyInCents,
        additionalEarnestMoneyInCents: input.currentTerms.purchase.additionalEarnestMoneyInCents,
        earnestMoneyHolder: input.currentTerms.purchase.earnestMoneyHolder,
        earnestMoneyDueDays: input.currentTerms.purchase.earnestMoneyDueDays,
        financingType: input.currentTerms.purchase.financingType,
        loanAmountInCents: input.currentTerms.purchase.loanAmountInCents,
      },
      disclosures: { ...input.currentTerms.disclosures },
    };
  }

  return sanitized;
}
