import type { StateOfferPackage } from '../../engine/models/state-offer-package';
import type { MarylandOfferTerms, MarylandContractType } from '../../../../core/domains/offers/state-contracts/maryland/models/maryland-offer-terms.model';
import { MARYLAND_RESIDENTIAL_CONTRACT_DEFINITION } from '../../../../core/domains/offers/state-contracts/maryland/models/maryland-offer-terms.model';
import { createMarylandInitialOfferTerms } from '../../../../core/domains/offers/state-contracts/maryland/services/maryland-initial-offer-terms.factory';
import { MARYLAND_RESIDENTIAL_SALE_SECTIONS } from './questions/maryland-residential-sale.sections';
import { MarylandOfferValidator } from './validators/maryland-offer.validator';
const validator = new MarylandOfferValidator();
export const MARYLAND_OFFER_PACKAGE: StateOfferPackage<MarylandOfferTerms, MarylandContractType> = {
  stateCode: 'MD', stateName: 'Maryland',
  contracts: { navstreet_maryland_residential_sale_2026: MARYLAND_RESIDENTIAL_CONTRACT_DEFINITION },
  createInitialTerms: input => createMarylandInitialOfferTerms(input),
  getSections: () => MARYLAND_RESIDENTIAL_SALE_SECTIONS,
  validate: (terms, buyers, sellers, context) => validator.validate(terms, [...buyers], [...sellers], context),
};
