import { selectOfferListingDocuments } from '../listing-document-policy.registry';
import {
  afterNextRender,
  ElementRef,
  inject,
  Injector,
  viewChild,
  ChangeDetectionStrategy,
  Component,
  computed,
  input,
  model,
  output,
  signal,
} from '@angular/core';

import type {
  OfferParty,
} from '../../../../core/domains/offers/models/offer-party.model';

import type {
  ListingDisclosureDocument,
} from '../../../../core/domains/disclosures/models/listing-disclosure-document.model';

import type {
  OfferValidationIssue,
} from '../../../../core/domains/offers/models/offer-validation.model';

import type {
  OfferQuestionCondition,
  OfferQuestionDefinition,
  OfferQuestionVisibilityRule,
} from '../models/offer-question-definition';

import type {
  OfferSectionDefinition,
  OfferSectionProgress,
} from '../models/offer-section-definition';

import {
  OfferQuestionRendererComponent,
} from '../question-renderer/question-renderer.component';

import { formatOfferPhone } from '../format-offer-phone';

import type {
  OfferDocumentSelection,
} from '../question-renderer/question-renderer.component';


export interface OfferFieldValueChange {
  readonly fieldPath: string;
  readonly value: unknown;
}

export interface OfferCoBuyerChange {
  readonly legalName: string;
  readonly email: string;
  readonly phone: string;
}

interface OfferReviewItem {
  readonly label: string;
  readonly value: string;
}

interface OfferReviewSection {
  readonly id: string;
  readonly title: string;
  readonly items: readonly OfferReviewItem[];
}


@Component({
  selector: 'app-offer-wizard-shell',

  standalone: true,

  imports: [
    OfferQuestionRendererComponent,
  ],

  templateUrl:
    './offer-wizard-shell.component.html',

  styleUrl:
    './offer-wizard-shell.component.scss',

  changeDetection:
    ChangeDetectionStrategy.OnPush,
})
export class OfferWizardShellComponent {
  private readonly renderInjector = inject(Injector);
  private readonly sectionTop = viewChild<ElementRef<HTMLElement>>('sectionTop');

  private scrollToSectionTop(): void {
    afterNextRender(() => {
      this.sectionTop()?.nativeElement.scrollIntoView({ block: 'start', behavior: 'instant' });
    }, { injector: this.renderInjector });
  }

  readonly stateName = input.required<string>();

  readonly title = input('Make an offer');

  readonly description = input(
    'Complete each section carefully. Your progress will be saved before the offer is submitted.'
  );

  readonly sections =
    input.required<
      readonly OfferSectionDefinition[]
    >();

  readonly terms = input.required<unknown>();

  // Compatibility with state templates that already bind this input.
  // Every state now validates required fields before advancing.
  readonly requireCompleteSection = input(true);

  readonly buyers = input<readonly OfferParty[]>([]);
  readonly allowBuyerEdits = input(true);
  readonly sellers = input<readonly OfferParty[]>([]);

  readonly listingDisclosures =
    input<readonly ListingDisclosureDocument[]>([]);

  readonly disclosureNotice = input<string | null>(null);

  readonly validationIssues =
    input<readonly OfferValidationIssue[]>([]);

  readonly currentSectionIndex = model(0);

  readonly saving = input(false);
  readonly allowEditingWhileSaving = input(false);
  readonly submitting = input(false);

  readonly submitLabel = input('Submit offer');

  readonly fieldValueChange =
    output<OfferFieldValueChange>();

  readonly documentSelected =
    output<OfferDocumentSelection>();

  readonly coBuyerChange =
    output<OfferCoBuyerChange | null>();

  readonly sectionChanged = output<number>();

  readonly submitRequested = output<void>();

  readonly returnToListingRequested =
    output<void>();

  readonly listingDisclosureRequested =
    output<ListingDisclosureDocument>();

  private readonly attemptedSectionIds =
    signal<ReadonlySet<string>>(new Set());

  private readonly touchedFieldPaths =
    signal<ReadonlySet<string>>(new Set());

  private readonly touchedCoBuyerFields =
    signal<ReadonlySet<'legalName' | 'email' | 'phone'>>(new Set());

  private readonly completedSectionIds =
    signal<ReadonlySet<string>>(new Set());

  protected readonly reviewing = signal(false);

  protected readonly addingCoBuyer = signal(false);
  protected readonly coBuyerLegalName = signal('');
  protected readonly coBuyerEmail = signal('');
  protected readonly coBuyerPhone = signal('');


  protected readonly visibleSections = computed(
    () =>
      this.sections().filter(
        section =>
          this.matchesVisibilityRule(
            section.visibleWhen
          )
      )
  );


  protected readonly normalizedSectionIndex = computed(
    () => {
      const sectionCount =
        this.visibleSections().length;

      if (sectionCount === 0) {
        return 0;
      }

      return Math.min(
        Math.max(this.currentSectionIndex(), 0),
        sectionCount - 1
      );
    }
  );


  protected readonly currentSection = computed(
    () =>
      this.visibleSections()[
        this.normalizedSectionIndex()
      ] ?? null
  );


  protected readonly progressPercent = computed(
    () => {
      const sectionCount =
        this.visibleSections().length;

      if (sectionCount === 0) {
        return 0;
      }

      return Math.round(
        (
          (this.normalizedSectionIndex() + 1) /
          sectionCount
        ) * 100
      );
    }
  );


  protected readonly sectionProgress = computed<
    readonly OfferSectionProgress[]
  >(
    () =>
      this.visibleSections().map(
        section => {
          const errorCount =
            this.sectionErrorCount(section);

          return {
            sectionId: section.id,
            complete: errorCount === 0,
            errorCount,
          };
        }
      )
  );


  protected readonly currentSectionErrorCount = computed(
    () => {
      const section = this.currentSection();

      return section
        ? this.sectionErrorCount(section)
        : 0;
    }
  );

  protected readonly reviewSections = computed<
    readonly OfferReviewSection[]
  >(() =>
    this.visibleSections().map(section => ({
      id: section.id,
      title: section.title,
      items: questionsForSection(section)
        .filter(
          question =>
            question.type !== 'information' &&
            question.fieldPath !== undefined &&
            this.isQuestionVisible(question)
        )
        .map(question => ({
          label: question.label,
          value: this.formatReviewValue(
            question,
            readPath(this.terms(), question.fieldPath as string)
          ),
        })),
    }))
  );


  protected readonly currentSectionValid = computed(
    () => this.currentSectionErrorCount() === 0 &&
      (this.currentSection()?.id !== 'disclosures' || !this.disclosureNotice())
  );

  protected readonly allSectionsValid = computed(
    () => this.visibleSections().every(section => this.sectionErrorCount(section) === 0) &&
      !this.disclosureNotice()
  );


 protected readonly currentSectionMissingLockedFields = computed(() => {
  const section = this.currentSection();

  if (!section) {
    return [];
  }

  return questionsForSection(section)
    .filter(question =>
      question.readOnly === true &&
      question.validation?.required === true &&
      this.isQuestionVisible(question) &&
      question.fieldPath !== undefined &&
      isRequiredValueMissing(
        readPath(this.terms(), question.fieldPath),
        question
      )
    )
    .map(question => question.label);
});


  protected readonly busy = computed(
    () => (!this.allowEditingWhileSaving() && this.saving()) || this.submitting()
  );


  protected readonly isLastSection = computed(
    () =>
      this.visibleSections().length > 0 &&
      this.normalizedSectionIndex() ===
        this.visibleSections().length - 1
  );

  protected questionValue(
    question: OfferQuestionDefinition,
  ): unknown {
    if (!question.fieldPath) {
      return null;
    }

    const value = readPath(
      this.terms(),
      question.fieldPath,
    );

    if (
      question.type === 'date_time' &&
      question.timeFieldPath
    ) {
      const time = readPath(
        this.terms(),
        question.timeFieldPath,
      );

      return typeof value === 'string' &&
        value &&
        typeof time === 'string' &&
        time
        ? `${value}T${time}`
        : '';
    }

    return value;
  }

  protected isQuestionVisible(
    question: OfferQuestionDefinition
  ): boolean {
    return this.matchesVisibilityRule(
      question.visibleWhen
    );
  }


  protected validationMessageFor(
    question: OfferQuestionDefinition
  ): string | null {
    if (!question.fieldPath) {
      return null;
    }
    const section = this.currentSection();
    if (!section ||
      (!this.attemptedSectionIds().has(section.id) &&
        !this.touchedFieldPaths().has(question.fieldPath))) {
      return null;
    }
    return this.questionValidationMessage(question);
  }

  private questionValidationMessage(question: OfferQuestionDefinition): string | null {
    if (!question.fieldPath) return null;
       const issue = this.validationIssues().find(
      issue =>
        issue.severity === 'error' &&
        (
          issue.fieldPath === question.fieldPath ||
          (
            question.type === 'date_time' &&
            issue.fieldPath === question.timeFieldPath
          ) ||
          issue.fieldPath.startsWith(
            `${question.fieldPath}.`,
          ) ||
          question.fieldPath.startsWith(
            `${issue.fieldPath}.`,
          )
        ),
    );
    if (issue) return issue.message;
    const rule = question.validation;
    if (!rule) return null;
    const value = this.questionValue(question);
    const missing = isRequiredValueMissing(value, question);
    if (rule.required && missing) return rule.message ?? 'Complete this field.';
    if (missing) return null;
    if (question.type === 'single_choice' &&
      !question.options.some(option => option.value === value))
      return rule.message ?? 'Select a valid option.';
    if (typeof value === 'number' || question.type === 'number' || question.type === 'currency') {
      const amount = Number(value);
      if (!Number.isFinite(amount) ||
          (rule.minimum !== undefined && amount < rule.minimum) ||
          (rule.maximum !== undefined && amount > rule.maximum))
        return rule.message ?? 'Enter a number in the permitted range.';
    }
    if (typeof value === 'string') {
      if (rule.minimumLength !== undefined && value.trim().length < rule.minimumLength)
        return rule.message ?? `Enter at least ${rule.minimumLength} characters.`;
      if (rule.maximumLength !== undefined && value.length > rule.maximumLength)
        return rule.message ?? `Enter no more than ${rule.maximumLength} characters.`;
      if (rule.pattern && !new RegExp(rule.pattern).test(value))
        return rule.message ?? 'Enter a valid value.';
      if ((question.type === 'date' || question.type === 'date_time') &&
          !Number.isFinite(Date.parse(value)))
        return rule.message ?? 'Enter a valid date.';
    }
    return null;
  }

  protected onFieldTouched(question: OfferQuestionDefinition): void {
    if (question.fieldPath) {
      this.touchedFieldPaths.set(new Set([...this.touchedFieldPaths(), question.fieldPath]));
    }
  }


  protected progressFor(
    sectionId: string
  ): OfferSectionProgress | null {
    return this.sectionProgress().find(
      progress =>
        progress.sectionId === sectionId
    ) ?? null;
  }

  protected isSectionComplete(sectionId: string): boolean {
    return this.completedSectionIds().has(sectionId) &&
      (this.progressFor(sectionId)?.errorCount ?? 0) === 0;
  }

  protected shouldShowSectionErrors(sectionId: string): boolean {
    return this.attemptedSectionIds().has(sectionId) &&
      (this.progressFor(sectionId)?.errorCount ?? 0) > 0;
  }

  protected shouldShowCurrentSectionError(): boolean {
    const section = this.currentSection();
    return !!section && this.shouldShowSectionErrors(section.id);
  }

  protected propertyValue(fieldName: string): string {
    const value = readPath(this.terms(), `property.${fieldName}`);
    return typeof value === 'string' ? value : '';
  }

  protected toggleCoBuyer(enabled: boolean): void {
    this.addingCoBuyer.set(enabled);
    this.touchedCoBuyerFields.set(new Set());
    this.emitCoBuyer();
  }

  protected touchCoBuyerField(field: 'legalName' | 'email' | 'phone'): void {
    this.touchedCoBuyerFields.set(new Set([...this.touchedCoBuyerFields(), field]));
  }

  protected coBuyerError(field: 'legalName' | 'email' | 'phone'): string | null {
    if (!this.addingCoBuyer()) return null;
    const value = field === 'legalName' ? this.coBuyerLegalName() :
      field === 'email' ? this.coBuyerEmail() : this.coBuyerPhone();
    if (!value.trim()) return `Enter the co-buyer’s ${field === 'legalName' ? 'legal name' : field}.`;
    if (field === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim()))
      return 'Enter a valid co-buyer email address.';
    return null;
  }

  protected updateCoBuyerField(
    field: 'legalName' | 'email' | 'phone',
    event: Event
  ): void {
    const input = event.target as HTMLInputElement;
    const value = field === 'phone'
      ? formatOfferPhone(input.value, true)
      : input.value;

    if (field === 'phone') input.value = value;

    if (field === 'legalName') {
      this.coBuyerLegalName.set(value);
    } else if (field === 'email') {
      this.coBuyerEmail.set(value);
    } else {
      this.coBuyerPhone.set(value);
    }

    this.emitCoBuyer();
  }

  private emitCoBuyer(): void {
    if (!this.addingCoBuyer()) {
      this.coBuyerChange.emit(null);
      return;
    }

    this.coBuyerChange.emit({
      legalName: this.coBuyerLegalName().trim(),
      email: this.coBuyerEmail().trim(),
      phone: this.coBuyerPhone().trim(),
    });
  }


  protected goToPreviousSection(): void {
    if (
      this.busy() ||
      this.normalizedSectionIndex() === 0
    ) {
      return;
    }

    this.setSectionIndex(
      this.normalizedSectionIndex() - 1
    );
  }


  protected continueOrSubmit(): void {
    if (this.busy()) {
      return;
    }

    const section = this.currentSection();
    if (!section) {
      return;
    }

    this.attemptedSectionIds.set(
      new Set([...this.attemptedSectionIds(), section.id])
    );

    if (!this.currentSectionValid()) {
      return;
    }

    this.completedSectionIds.set(
      new Set([...this.completedSectionIds(), section.id])
    );

    if (this.isLastSection()) {
      if (!this.allSectionsValid()) {
        const firstInvalid = this.visibleSections().findIndex(section =>
          this.sectionErrorCount(section) > 0 ||
          (section.id === 'disclosures' && !!this.disclosureNotice()));
        if (firstInvalid >= 0) this.setSectionIndex(firstInvalid);
        return;
      }
      this.reviewing.set(true);
      this.scrollToSectionTop();
      return;
    }

    this.setSectionIndex(
      this.normalizedSectionIndex() + 1
    );
  }

  protected onValueChange(
    question: OfferQuestionDefinition,
    value: unknown,
  ): void {
    if (!question.fieldPath) {
      return;
    }

    this.reviewing.set(false);

    const section = this.currentSection();

    if (section) {
      const completed = new Set(
        this.completedSectionIds(),
      );

      completed.delete(section.id);
      this.completedSectionIds.set(completed);
    }

    if (
      question.type === 'date_time' &&
      question.timeFieldPath
    ) {
      const combined =
        typeof value === 'string' ? value : '';

      const valid =
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(combined);

      this.fieldValueChange.emit({
        fieldPath: question.fieldPath,
        value: valid ? combined.slice(0, 10) : '',
      });

      this.fieldValueChange.emit({
        fieldPath: question.timeFieldPath,
        value: valid ? combined.slice(11, 16) : '',
      });

      return;
    }

    this.fieldValueChange.emit({
      fieldPath: question.fieldPath,
      value,
    });
  }

  protected returnToCertification(): void {
    this.reviewing.set(false);
    this.scrollToSectionTop();
  }

  protected editReviewSection(sectionId: string): void {
    const index = this.visibleSections().findIndex(
      section => section.id === sectionId
    );

    if (index < 0 || this.busy()) {
      return;
    }

    if (index > this.normalizedSectionIndex()) {
      const firstInvalid = this.visibleSections().findIndex((section, sectionIndex) =>
        sectionIndex < index && (this.sectionErrorCount(section) > 0 ||
          (section.id === 'disclosures' && !!this.disclosureNotice())));
      if (firstInvalid >= 0) {
        const invalidSection = this.visibleSections()[firstInvalid];
        this.attemptedSectionIds.set(
          new Set([...this.attemptedSectionIds(), invalidSection.id])
        );
        this.reviewing.set(false);
        this.setSectionIndex(firstInvalid);
        return;
      }
    }
    this.reviewing.set(false);
    this.setSectionIndex(index);
  }


  protected confirmSubmit(): void {
    if (this.busy()) {
      return;
    }
    if (!this.allSectionsValid()) {
      this.attemptedSectionIds.set(new Set(this.visibleSections().map(section => section.id)));
      this.reviewing.set(false);
      const firstInvalid = this.visibleSections().findIndex(section =>
        this.sectionErrorCount(section) > 0 ||
        (section.id === 'disclosures' && !!this.disclosureNotice()));
      if (firstInvalid >= 0) this.setSectionIndex(firstInvalid);
      return;
    }

    this.submitRequested.emit();
  }


  protected reviewMoney(fieldPath: string): string {
    const value = readPath(this.terms(), fieldPath);
    const cents = typeof value === 'number' ? value : 0;

    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(cents / 100);
  }


  protected formatPhone(value: string): string {
    return formatOfferPhone(value);
  }

  protected sectionLabel(value: string): string {
    return value.replace(/^\s*\d+\s*[.:-]?\s*/, '').trim();
  }

  protected partyNames(parties: readonly OfferParty[]): string {
    const names = parties
      .map(party => party.legalName.trim())
      .filter(Boolean);

    return names.length > 0 ? names.join(', ') : 'Not provided';
  }


  protected reviewText(fieldPath: string): string {
    const value = readPath(this.terms(), fieldPath);
    return typeof value === 'string' && value.trim()
      ? value
      : 'Not provided';
  }

  private formatReviewValue(
    question: OfferQuestionDefinition,
    value: unknown
  ): string {
    if (question.type === 'currency') {
      return typeof value === 'number' && Number.isFinite(value)
        ? new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
          }).format(value / 100)
        : 'Not provided';
    }

    if (question.type === 'number') {
      return typeof value === 'number' && Number.isFinite(value)
        ? `${new Intl.NumberFormat('en-US').format(value)}${question.suffix ? ` ${question.suffix}` : ''}`
        : 'Not provided';
    }

    if (question.type === 'yes_no' || question.type === 'acknowledgement') {
      return value === true ? 'Yes' : value === false ? 'No' : 'Not provided';
    }

    if (question.type === 'single_choice' || question.type === 'multiple_choice') {
      const selectedValues = selectedChoiceValues(question, value);
      const labels = question.options
        .filter(option => selectedValues.has(option.value))
        .map(option => option.label);

      return labels.length > 0 ? labels.join(', ') : 'None selected';
    }

    if (question.type === 'address') {
      return formatReviewAddress(value);
    }

    if (question.type === 'document_upload') {
      return isEmpty(value) ? 'Not provided' : 'Document uploaded';
    }

    if (question.type === 'date_time' && typeof value === 'string') {
      const parsed = new Date(value);
      return Number.isFinite(parsed.getTime())
        ? new Intl.DateTimeFormat('en-US', {
            dateStyle: 'medium',
            timeStyle: 'short',
          }).format(parsed)
        : 'Not provided';
    }

    if (Array.isArray(value)) {
      return value.length > 0
        ? value.map(item => String(item)).join(', ')
        : 'None';
    }

    if (typeof value === 'string') {
      return value.trim() || 'Not provided';
    }

    return value === null || value === undefined
      ? 'Not provided'
      : String(value);
  }


  protected hasValue(fieldPath: string): boolean {
    const value = readPath(this.terms(), fieldPath);
    return value !== undefined && value !== null && value !== '';
  }


  protected listingDocumentsForSection(
    sectionId: string
  ): readonly ListingDisclosureDocument[] {
    return selectOfferListingDocuments(sectionId, this.terms(), this.listingDisclosures());
  }


  protected onDocumentSelected(
    selection: OfferDocumentSelection
  ): void {
    this.documentSelected.emit(selection);
  }


  private setSectionIndex(index: number): void {
    this.currentSectionIndex.set(index);
    this.sectionChanged.emit(index);
    this.scrollToSectionTop();
  }


  private sectionErrorCount(
    section: OfferSectionDefinition
  ): number {
    if (section.id === 'parties') {
      const partyIssues = this.validationIssues().filter(
        issue => issue.severity === 'error' &&
          (issue.fieldPath === 'buyers' ||
            issue.fieldPath.startsWith('buyers.') ||
            issue.fieldPath === 'sellers' ||
            issue.fieldPath.startsWith('sellers.'))
      ).length;
      return partyIssues + (this.addingCoBuyer() &&
        (this.coBuyerError('legalName') || this.coBuyerError('email') || this.coBuyerError('phone')) ? 1 : 0);
    }

    const visibleQuestions = questionsForSection(section).filter(
      question =>
        this.isQuestionVisible(question) &&
        question.fieldPath
    );

    const fieldPaths = new Set(
      visibleQuestions.map(
        question => question.fieldPath as string
      )
    );

    const errorKeys = new Set(
      this.validationIssues()
        .filter(
          issue =>
            issue.severity === 'error' &&
            Array.from(fieldPaths).some(
              fieldPath =>
                issue.fieldPath === fieldPath ||
                issue.fieldPath.startsWith(`${fieldPath}.`) ||
                fieldPath.startsWith(`${issue.fieldPath}.`)
            )
        )
        .map(issue => issue.fieldPath)
    );

    for (const question of visibleQuestions)
      if (question.fieldPath && this.questionValidationMessage(question))
        errorKeys.add(question.fieldPath);

    return errorKeys.size;
  }


  private matchesVisibilityRule(
    rule:
      OfferQuestionVisibilityRule |
      undefined
  ): boolean {
    if (!rule) {
      return true;
    }

    const results = rule.conditions.map(
      condition =>
        evaluateCondition(
          this.terms(),
          condition
        )
    );

    return rule.match === 'all'
      ? results.every(Boolean)
      : results.some(Boolean);
  }
}


function questionsForSection(
  section: OfferSectionDefinition
): readonly OfferQuestionDefinition[] {
  return section.questionGroups?.length
    ? section.questionGroups.flatMap(group => group.questions)
    : section.questions;
}

function selectedChoiceValues(
  question: Extract<
    OfferQuestionDefinition,
    { readonly type: 'single_choice' | 'multiple_choice' }
  >,
  value: unknown
): ReadonlySet<string> {
  if (!Array.isArray(value)) {
    return new Set(typeof value === 'string' ? [value] : []);
  }

  if (!question.objectSelection) {
    return new Set(
      value.filter((item): item is string => typeof item === 'string')
    );
  }

  const valueKey = question.objectSelection.valueKey;
  const selectedKey = question.objectSelection.selectedKey ?? 'included';

  return new Set(
    value.flatMap(item => {
      if (item === null || typeof item !== 'object' || Array.isArray(item)) {
        return [];
      }

      const record = item as Record<string, unknown>;
      return record[selectedKey] === true && typeof record[valueKey] === 'string'
        ? [record[valueKey] as string]
        : [];
    })
  );
}

function formatReviewAddress(value: unknown): string {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    return 'Not provided';
  }

  const address = value as Record<string, unknown>;
  const street = [address['addressLine1'], address['addressLine2']]
    .filter(part => typeof part === 'string' && part.trim())
    .join(' ');
  const locality = [address['city'], address['state'], address['zipCode']]
    .filter(part => typeof part === 'string' && part.trim())
    .join(' ');
  const county = typeof address['county'] === 'string' && address['county'].trim()
    ? `${address['county']} County`
    : '';

  return [street, locality, county].filter(Boolean).join(', ') || 'Not provided';
}


function evaluateCondition(
  terms: unknown,
  condition: OfferQuestionCondition
): boolean {
  const actual = readPath(
    terms,
    condition.fieldPath
  );

  switch (condition.operator) {
    case 'equals':
      return actual === condition.value;

    case 'not_equals':
      return actual !== condition.value;

    case 'includes':
      return Array.isArray(actual) &&
        actual.includes(condition.value);

    case 'not_includes':
      return !Array.isArray(actual) ||
        !actual.includes(condition.value);

    case 'is_empty':
      return isEmpty(actual);

    case 'is_not_empty':
      return !isEmpty(actual);

    case 'is_true':
      return actual === true;

    case 'is_false':
      return actual === false;
  }
}


function readPath(
  source: unknown,
  fieldPath: string
): unknown {
  return fieldPath
    .split('.')
    .reduce<unknown>(
      (value, key) => {
        if (Array.isArray(value)) {
          const numericIndex = Number(key);

          if (
            Number.isInteger(numericIndex) &&
            numericIndex >= 0
          ) {
            return value[numericIndex];
          }

          return value.find(item => {
            if (
              item === null ||
              typeof item !== 'object' ||
              Array.isArray(item)
            ) {
              return false;
            }

            const record =
              item as Record<string, unknown>;

            return record['formId'] === key ||
              record['id'] === key ||
              record['value'] === key;
          });
        }

        if (
          value === null ||
          typeof value !== 'object'
        ) {
          return undefined;
        }

        return (
          value as Record<string, unknown>
        )[key];
      },
      source
    );
}


function isEmpty(value: unknown): boolean {
  return value === null ||
    value === undefined ||
    value === '' ||
    (
      Array.isArray(value) &&
      value.length === 0
    );
}


function isRequiredValueMissing(
  value: unknown,
  question: OfferQuestionDefinition
): boolean {
  if (question.type === 'acknowledgement') {
    return value !== true;
  }

  if (
    question.type === 'multiple_choice' &&
    question.objectSelection &&
    Array.isArray(value)
  ) {
    const selectedKey =
      question.objectSelection.selectedKey ?? 'included';

    return !value.some(
      item =>
        item !== null &&
        typeof item === 'object' &&
        !Array.isArray(item) &&
        (item as Record<string, unknown>)[selectedKey] === true
    );
  }

  return value === undefined ||
    value === null ||
    value === 'unselected' ||
    (
      typeof value === 'string' &&
      value.trim().length === 0
    ) ||
    (
      Array.isArray(value) &&
      value.length === 0
    );
}
