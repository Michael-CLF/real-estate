import { getListingContractCoverageMessage } from '../../../../offers/engine/state-offer-registry';
import { getOfferBlockingDocumentTypes, checklistDocumentTitle } from '../../../../../core/configuration/listing-document-checklist.config';
import { californiaDisclosureOutstanding, validCaliforniaDisclosureDecision, type CaliforniaDisclosureType } from '../../../../../core/domains/listings/state-packages/california/california-listing-facts.model';
import { STATES } from '../../../../../core/configuration/states.config';
import { PageSeoService } from '../../../../../core/seo/page-seo.service';
import { newOfferPath } from '../../../../offers/engine/state-offer-registry';
import {
  ChangeDetectionStrategy,
  Component,
  OnInit,
  inject,
  signal
} from '@angular/core';

import {
  AsyncPipe,
  CurrencyPipe,
  DecimalPipe
} from '@angular/common';

import {
  ActivatedRoute,
  Router,
  RouterLink
} from '@angular/router';

import {
  RequestShowingComponent
} from '../../components/request-showing/request-showing.component';

import {
  AnalyticsDataLayerService
} from '../../../../../core/analytics/analytics-data-layer.service';

import {
  catchError,
  filter,
  firstValueFrom,
  map,
  Observable,
  of,
  shareReplay,
  switchMap,
  take,
  tap
} from 'rxjs';

import {
  toObservable
} from '@angular/core/rxjs-interop';

import {
  AuthState
} from '../../../../../core/authentication/state/auth.state';

import {
  MarketplaceListing
} from '../../../../../core/domains/marketplace/models/marketplace-listing.model';

import {
  MarketplaceListingRepository
} from '../../../../../core/domains/marketplace/repositories/marketplace-listing.repository';

import {
  FirestoreMarketplaceListingRepository
} from '../../../../../core/domains/marketplace/repositories/firestore-marketplace-listing.repository';

import {
  SavedListingService
} from '../../../../../core/domains/marketplace/services/saved-listing.service';

import {
  ListingEnhancements,
  ListingSchool,
  ListingSchools
} from '../../../../../core/domains/listings/models/listing.model';

import {
  ListingGalleryComponent
} from '../../components/listing-gallery/listing-gallery.component';

import {
  ListingMortgageCalculatorComponent
} from '../../components/listing-mortgage-calculator/listing-mortgage-calculator.component';

import {
  ListingBadge
} from '../../../../../core/domains/listings/models/listing-badge.model';

import {
  ListingBadgeService
} from '../../../../../core/domains/listings/services/listing-badge.service';

import {
  ContactSellerComponent
} from '../../components/contact-seller/contact-seller.component';

import {
  ListingViewService
} from '../../../../../core/domains/marketplace/services/listing-view.service';

import {
  MortgageCostEstimationService
} from '../../../../../core/domains/marketplace/services/mortgage-cost-estimation.service';

import {
  ListingDisclosureDocument
} from '../../../../../core/domains/disclosures/models/listing-disclosure-document.model';

import {
  DisclosureDocumentType
} from '../../../../../core/domains/disclosures/models/state-disclosure-requirement.model';

import {
  ListingDisclosureService
} from '../../../../../core/domains/disclosures/services/listing-disclosure.service';

import {
  getStateDisclosureRequirements
} from '../../../../../core/configuration/state-disclosures.config';


interface ListingFact {
  label: string;
  value: string;
  icon: string;
}

interface EnhancementGroup {
  id: keyof ListingEnhancements;
  title: string;
  icon: string;
  features: string[];
}

interface NearbySchoolCard {
  id:
  | 'elementary'
  | 'middle'
  | 'high';

  level: string;
  icon: string;
  name: string;
  schoolType: string;
  grades?: string;
  distance?: string;
  district?: string;
}

interface NearbySchoolsViewModel {
  districtName?: string;
  assignedSchoolsVerified: boolean;
  schools: NearbySchoolCard[];
}

interface ListingDetailsViewModel {
  listing: MarketplaceListing | null;
  facts: ListingFact[];
  enhancementGroups: EnhancementGroup[];
  nearbySchools: NearbySchoolsViewModel | null;
  badges: ListingBadge[];
  hasError: boolean;
}

const ENHANCEMENT_SECTIONS: ReadonlyArray<
  Omit<EnhancementGroup, 'features'>
> = [
    { id: 'construction', title: 'Construction & Exterior', icon: 'fa-solid fa-house-chimney' },
    { id: 'interior', title: 'Interior & Living Spaces', icon: 'fa-solid fa-couch' },
    { id: 'kitchen', title: 'Kitchen', icon: 'fa-solid fa-kitchen-set' },
    { id: 'bedroomsBathrooms', title: 'Bedrooms & Bathrooms', icon: 'fa-solid fa-bed' },
    { id: 'parkingStorage', title: 'Parking & Storage', icon: 'fa-solid fa-car' },
    { id: 'outdoorLiving', title: 'Outdoor Living', icon: 'fa-solid fa-umbrella-beach' },
    { id: 'systemsUtilities', title: 'Systems, Utilities & Efficiency', icon: 'fa-solid fa-bolt' },
    { id: 'technologySecurity', title: 'Technology & Security', icon: 'fa-solid fa-house-signal' },
    { id: 'accessibility', title: 'Accessibility', icon: 'fa-solid fa-universal-access' },
    { id: 'communityAmenities', title: 'Community Amenities', icon: 'fa-solid fa-people-roof' }
  ];

@Component({
  selector: 'app-listing-details',
  standalone: true,
  imports: [
    AsyncPipe,
    CurrencyPipe,
    DecimalPipe,
    RouterLink,
    ListingGalleryComponent,
    ListingMortgageCalculatorComponent,
    RequestShowingComponent,
    ContactSellerComponent
  ],
  providers: [
    {
      provide: MarketplaceListingRepository,
      useClass: FirestoreMarketplaceListingRepository
    }
  ],
  templateUrl: './listing-details.component.html',
  styleUrl: './listing-details.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ListingDetailsComponent
  implements OnInit {
  private readonly pageSeo = inject(PageSeoService);

  listingLocation(listing: MarketplaceListing): string {
    const address = listing.address;
    const state = STATES.find(item => item.slug === address.stateSlug ||
      item.abbreviation === address.stateAbbreviation?.trim().toUpperCase() ||
      item.name.toLowerCase() === address.state?.trim().toLowerCase());
    return [address.city?.trim(), state?.name || address.state?.trim() || address.stateAbbreviation?.trim()]
      .filter(Boolean).join(', ');
  }

  listingOwnerHeading(listing: MarketplaceListing): string {
    const location = this.listingLocation(listing);
    const prefix = listing.status === 'sold' ? 'Sold by owner' : 'For sale by owner';
    return location ? `${prefix} in ${location}` : prefix;
  }

  private updateListingSeo(listing: MarketplaceListing | null): void {
    if (!listing) {
      this.pageSeo.set('Listing unavailable | NavStreet', 'This property listing is unavailable.', true);
      return;
    }
    const address = listing.address.addressLine1?.trim() || listing.title;
    const heading = this.listingOwnerHeading(listing);
    this.pageSeo.set(`${address} — ${heading} | NavStreet`,
      `${heading}. View property details, photos and the seller’s description on NavStreet.`);
  }


  private readonly route =
    inject(ActivatedRoute);

  private readonly router =
    inject(Router);

  private readonly authState =
    inject(AuthState);

  private readonly authenticationReady$ =
    toObservable(
      this.authState.loading
    ).pipe(
      filter(
        isLoading =>
          !isLoading
      ),
      take(1)
    );

  private readonly listingRepository =
    inject(MarketplaceListingRepository);

  private readonly savedListingService =
    inject(SavedListingService);

  private readonly listingViewService =
    inject(ListingViewService);

  private readonly listingBadgeService =
    inject(ListingBadgeService);

  private readonly mortgageCostEstimationService =
    inject(MortgageCostEstimationService);

  private readonly analytics =
    inject(AnalyticsDataLayerService);

  private readonly disclosureService =
    inject(ListingDisclosureService);

  readonly isSaved =
    signal(false);

  readonly isSaving =
    signal(false);

  readonly saveError =
    signal('');

  readonly displayedViewCount =
    signal(0);

  readonly disclosures =
    signal<
      readonly ListingDisclosureDocument[]
    >([]);

  readonly disclosuresAreLoading =
    signal(false);

  readonly disclosureBeingOpened =
    signal<string | null>(null);

  readonly disclosureLoadError =
    signal('');

  readonly disclosureOpenError =
    signal('');

  requiredOfferDocumentTypes(listing: MarketplaceListing): readonly DisclosureDocumentType[] {
    const state = listing.address.stateAbbreviation;
    const required = new Set(getOfferBlockingDocumentTypes(state, {
      ...listing.sellerStatements,
      yearBuilt: listing.yearBuilt,
      propertyType: listing.propertyType
    }));
    // Show documents needed before signing before the buyer enters the wizard.
    // California uses the seller's recorded applicability and exemption decisions.
    if (state !== 'CA' && listing.propertyType !== 'land' &&
        (listing.sellerStatements?.leadBasedPaintApplies === true ||
         (listing.sellerStatements?.leadBasedPaintApplies !== false &&
          (listing.yearBuilt == null || listing.yearBuilt < 1978)))) {
      required.add('lead-based-paint');
    }
    return [...required];
  }

  requiredOfferDisclosureTitles(listing: MarketplaceListing): string[] {
    const state = listing.address.stateAbbreviation;
    const uploaded = new Set(this.disclosures()
      .filter(document => document.listingUid === listing.uid &&
        document.stateAbbreviation === state &&
        Boolean(document.storagePath) && Boolean(document.versionId))
      .map(document => document.documentType));
    return this.requiredOfferDocumentTypes(listing)
      .filter(type => !uploaded.has(type))
      .map(type => checklistDocumentTitle(state, type));
  }

  contractCoverageMessage(listing: MarketplaceListing): string | null {
    return getListingContractCoverageMessage(listing.address.stateAbbreviation, listing.propertyType, listing.sellerStatements?.contractFacts);
  }

  offerDisclosuresAreReady(listing: MarketplaceListing): boolean {
    if (this.contractCoverageMessage(listing)) return false;
    if (this.requiredOfferDocumentTypes(listing).length === 0) return true;
    return !this.authenticationIsLoading() && this.isAuthenticated()
      && !this.disclosuresAreLoading() && !this.disclosureLoadError()
      && this.requiredOfferDisclosureTitles(listing).length === 0;
  }

  californiaDisclosureExplanations(listing: MarketplaceListing): { type: string; title: string; status: string; basis: string }[] {
    if (listing.address.stateAbbreviation !== 'CA') return [];
    return getStateDisclosureRequirements('CA').flatMap(requirement => {
      const decision = listing.sellerStatements?.california?.disclosureApplicability?.[requirement.documentType as CaliforniaDisclosureType];
      return validCaliforniaDisclosureDecision(decision) && decision.status !== 'required'
        ? [{ type: requirement.documentType, title: requirement.shortTitle, status: decision.status === 'exempt' ? 'Seller reports an exemption' : 'Seller reports this does not apply', basis: decision.basis }]
        : [];
    });
  }

  readonly viewModel$:
    Observable<ListingDetailsViewModel> =
    this.route.paramMap.pipe(
      map(
        params =>
          params.get('listingId') ?? ''
      ),

      switchMap(
        listingId =>
          this.listingRepository
            .getListingById(listingId)
            .pipe(
              map(
                listing => ({
                  listing,

                  facts:
                    listing
                      ? this.createListingFacts(
                        listing
                      )
                      : [],

                  enhancementGroups:
                    listing
                      ? this.createEnhancementGroups(
                        listing.enhancements
                      )
                      : [],

                  nearbySchools:
                    listing
                      ? this.createNearbySchools(
                        listing.schools
                      )
                      : null,

                  badges:
                    listing
                      ? this.listingBadgeService
                        .getBadges(listing)
                      : [],


                  hasError: false
                })
              ),

              catchError(
                () =>
                  of({
                    listing: null,
                    facts: [],
                    enhancementGroups: [],
                    nearbySchools: null,
                    badges: [],
                    hasError: true
                  })
              )
            )
      ),

      tap(viewModel => this.updateListingSeo(viewModel.listing)),
      shareReplay({
        bufferSize: 1,
        refCount: true
      })
    );

  async ngOnInit(): Promise<void> {
    const viewModel =
      await firstValueFrom(
        this.viewModel$
      );

    if (!viewModel.listing) {
      return;
    }

    /*
     * Use the public route parameter as the canonical
     * Firestore listing document identifier.
     */
    const listingDocumentUid =
      this.route.snapshot.paramMap.get(
        'listingId'
      ) ??
      viewModel.listing.uid;

    this.analytics.track(
      'listing_viewed',
      {
        listing_id:
          viewModel.listing.uid,

        property_type:
          viewModel.listing.propertyType,

        list_price:
          viewModel.listing.price
      }
    );

    /*
     * View recording is independent of saved-listing
     * state and also supports anonymous visitors.
     */
    try {
      const viewResult =
        await this.listingViewService
          .recordListingView(
            viewModel.listing.uid
          );

      this.displayedViewCount.set(
        viewResult.viewCount
      );
    } catch (error: unknown) {
      /*
       * Metrics must never prevent the public listing
       * from loading or displaying normally.
       */
      console.error(
        'Unable to record listing view:',
        error
      );
    }

    /*
  * Wait until Firebase has determined whether the browser
  * has an authenticated session. Without this wait, a page
  * refresh can temporarily appear signed out and skip
  * disclosure and saved-listing loading.
  */
    await firstValueFrom(
      this.authenticationReady$
    );

    const userUid =
      this.authState.uid();

    if (!userUid) {
      return;
    }

    await this.loadDisclosures(
      viewModel.listing.uid
    );
    try {
      const saved =
        await this.savedListingService
          .isListingSaved(
            userUid,
            viewModel.listing.uid
          );

      this.isSaved.set(saved);

      const shouldSave =
        this.route.snapshot
          .queryParamMap
          .get(
            'saveListing'
          ) === 'true';

      if (
        shouldSave &&
        !saved
      ) {
        await this.saveListing(
          userUid,
          viewModel.listing
        );
      }

      if (shouldSave) {
        await this.router.navigate(
          [],
          {
            relativeTo:
              this.route,

            queryParams: {
              saveListing: null
            },

            queryParamsHandling:
              'merge',

            replaceUrl: true
          }
        );
      }
    } catch (error: unknown) {
      console.error(
        'Unable to load saved-listing status.',
        error
      );

      this.saveError.set(
        'We could not load your saved-listing status.'
      );
    }
  }


  offerPath(listing: MarketplaceListing): readonly string[] {
    return newOfferPath(listing.address.stateAbbreviation || listing.address.state, listing.uid);
  }

  async toggleSavedListing(
    listing: MarketplaceListing
  ): Promise<void> {
    if (this.isSaving()) {
      return;
    }

    const userUid =
      this.authState.uid();

    if (!userUid) {
      const returnUrl =
        this.router.createUrlTree(
          [
            '/listings',
            listing.uid
          ],
          {
            queryParams: {
              saveListing: true
            }
          }
        ).toString();

      await this.router.navigate(
        ['/sign-in'],
        {
          queryParams: {
            returnUrl
          }
        }
      );

      return;
    }

    this.isSaving.set(true);
    this.saveError.set('');

    try {
      if (this.isSaved()) {
        await this.savedListingService
          .removeSavedListing(
            userUid,
            listing.uid
          );

        this.isSaved.set(false);

        this.analytics.track(
          'listing_unsaved',
          {
            listing_id:
              listing.uid,

            property_type:
              listing.propertyType,

            list_price:
              listing.price
          }
        );

      } else {
        await this.saveListing(
          userUid,
          listing
        );
      }

    } catch (error) {
      console.error(
        'Unable to update saved listing.',
        error
      );

      this.saveError.set(
        'We could not update this saved listing. Please try again.'
      );

    } finally {
      this.isSaving.set(false);
    }
  }

  authenticationIsLoading(): boolean {
    return this.authState.loading();
  }

  isAuthenticated(): boolean {
    return this.authState.isAuthenticated();
  }

  disclosureTitle(
    documentType:
      DisclosureDocumentType,
    stateAbbreviation: string
  ): string {
    const requirement =
      getStateDisclosureRequirements(
        stateAbbreviation
      ).find(
        currentRequirement =>
          currentRequirement.documentType ===
          documentType
      );

    return (
      requirement?.title ??
      'Property Disclosure'
    );
  }

  async openDisclosure(
    disclosure:
      ListingDisclosureDocument
  ): Promise<void> {
    if (this.disclosureBeingOpened()) {
      return;
    }

    this.disclosureOpenError.set('');

    this.disclosureBeingOpened.set(
      disclosure.id
    );

    try {
      await this.disclosureService
        .openDisclosure(disclosure);
    } catch (error: unknown) {
      console.error(
        'Unable to open property disclosure:',
        error
      );

      this.disclosureOpenError.set(
        error instanceof Error
          ? error.message
          : 'The disclosure document could not be opened.'
      );
    } finally {
      this.disclosureBeingOpened.set(null);
    }
  }

  private async loadDisclosures(
    listingUid: string
  ): Promise<void> {
    this.disclosuresAreLoading.set(true);
    this.disclosureLoadError.set('');

    try {
      const summaries =
        await this.disclosureService
          .getListingDisclosures(
            listingUid
          );

      this.disclosures.set(
        summaries.map(
          summary =>
            summary.currentDocument
        )
      );
    } catch (error: unknown) {
      console.error(
        'Unable to load property disclosures:',
        error
      );

      this.disclosures.set([]);

      this.disclosureLoadError.set(
        'Property disclosures could not be loaded. Please try again.'
      );
    } finally {
      this.disclosuresAreLoading.set(false);
    }
  }

  private async saveListing(
    userUid: string,
    listing: MarketplaceListing
  ): Promise<void> {
    await this.savedListingService
      .saveListing(
        userUid,
        listing
      );

    this.isSaved.set(true);

    this.analytics.track(
      'listing_saved',
      {
        listing_id:
          listing.uid,

        property_type:
          listing.propertyType,

        list_price:
          listing.price
      }
    );
  }

  private createListingFacts(
    listing: MarketplaceListing
  ): ListingFact[] {
    const facts: ListingFact[] = [];

    facts.push({
      label: 'Property type',
      value:
        this.formatPropertyType(
          listing.propertyType
        ),
      icon: 'fa-solid fa-house'
    });

    if (listing.bedrooms !== undefined) {
      facts.push({
        label: 'Bedrooms',
        value:
          listing.bedrooms.toString(),
        icon: 'fa-solid fa-bed'
      });
    }

    if (listing.bathrooms !== undefined) {
      facts.push({
        label: 'Bathrooms',
        value:
          listing.bathrooms.toString(),
        icon: 'fa-solid fa-bath'
      });
    }

    if (listing.squareFeet !== undefined) {
      facts.push({
        label: 'Square feet',
        value:
          listing.squareFeet.toLocaleString(),
        icon: 'fa-solid fa-ruler-combined'
      });
    }

    const lotSize =
      listing.lotSize ??
      listing.lotSizeAcres;

    if (lotSize !== undefined) {
      facts.push({
        label: 'Lot size',
        value:
          this.formatLotSize(
            lotSize,
            listing.lotSizeUnit ??
            'acres'
          ),
        icon: 'fa-solid fa-map'
      });
    }

    if (listing.yearBuilt !== undefined) {
      facts.push({
        label: 'Year built',
        value:
          listing.yearBuilt.toString(),
        icon: 'fa-solid fa-calendar'
      });
    }

    if (listing.hoa) {
      facts.push({
        label: 'HOA',
        value:
          listing.hoa.hasHoa
            ? 'Yes'
            : 'No',
        icon: 'fa-solid fa-people-roof'
      });

      if (
        listing.hoa.hasHoa &&
        listing.hoa.feeAmount !== undefined &&
        listing.hoa.feeFrequency
      ) {
        facts.push({
          label: 'HOA fee',
          value:
            `${this.formatCurrency(
              listing.hoa.feeAmount
            )} ${this.formatHoaFrequency(
              listing.hoa.feeFrequency
            )}`,
          icon: 'fa-solid fa-dollar-sign'
        });
      }
    }



    return facts;
  }

  private createNearbySchools(
    schools?: ListingSchools
  ): NearbySchoolsViewModel | null {
    if (!schools) {
      return null;
    }

    const schoolCards: NearbySchoolCard[] = [];

    this.addNearbySchool(
      schoolCards,
      'elementary',
      'Elementary School',
      'fa-solid fa-child-reaching',
      schools.elementarySchool
    );

    this.addNearbySchool(
      schoolCards,
      'middle',
      'Middle School',
      'fa-solid fa-book-open',
      schools.middleSchool
    );

    this.addNearbySchool(
      schoolCards,
      'high',
      'High School',
      'fa-solid fa-graduation-cap',
      schools.highSchool
    );

    if (schoolCards.length === 0) {
      return null;
    }

    return {
      districtName:
        schools.districtName,

      assignedSchoolsVerified:
        schools.assignedSchoolsVerified,

      schools:
        schoolCards
    };
  }

  private addNearbySchool(
    schoolCards: NearbySchoolCard[],
    id: NearbySchoolCard['id'],
    level: string,
    icon: string,
    school?: ListingSchool
  ): void {
    if (!school?.name) {
      return;
    }

    schoolCards.push({
      id,
      level,
      icon,
      name: school.name,

      schoolType:
        this.formatSchoolType(
          school.schoolType
        ),

      grades:
        school.grades,

      distance:
        school.distanceMiles !== undefined
          ? this.formatSchoolDistance(
            school.distanceMiles
          )
          : undefined,

      district:
        school.district
    });
  }

  private formatSchoolType(
    schoolType: ListingSchool['schoolType']
  ): string {
    switch (schoolType) {
      case 'charter':
        return 'Charter school';

      case 'magnet':
        return 'Magnet school';

      case 'private':
        return 'Private school';

      case 'public':
      default:
        return 'Public school';
    }
  }

  private formatSchoolDistance(
    distanceMiles: number
  ): string {
    const formattedDistance =
      new Intl.NumberFormat(
        'en-US',
        {
          maximumFractionDigits: 1
        }
      ).format(distanceMiles);

    return distanceMiles === 1
      ? `${formattedDistance} mile away`
      : `${formattedDistance} miles away`;
  }

  private createEnhancementGroups(
    enhancements?: ListingEnhancements
  ): EnhancementGroup[] {
    if (!enhancements) {
      return [];
    }

    return ENHANCEMENT_SECTIONS
      .map(section => ({
        ...section,

        features: (
          enhancements[section.id] ?? []
        )
          .map(featureId =>
            this.formatFeatureLabel(
              featureId
            )
          )
          .sort(
            (
              firstFeature,
              secondFeature
            ) =>
              firstFeature.localeCompare(
                secondFeature,
                'en',
                {
                  sensitivity: 'base'
                }
              )
          )
      }))
      .filter(
        group =>
          group.features.length > 0
      )
      .sort(
        (
          firstGroup,
          secondGroup
        ) =>
          firstGroup.title.localeCompare(
            secondGroup.title,
            'en',
            {
              sensitivity: 'base'
            }
          )
      );
  }

  private formatFeatureLabel(
    featureId: string
  ): string {
    const label = featureId
      .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
      .replace(/[-_]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .replace(/\b\w/g, character =>
        character.toUpperCase()
      );

    return label
      .replace(/\bHoa\b/g, 'HOA')
      .replace(/\bHvac\b/g, 'HVAC')
      .replace(/\bEv\b/g, 'EV')
      .replace(/\bRv\b/g, 'RV')
      .replace(/\bWifi\b/g, 'Wi-Fi')
      .replace(/\bLed\b/g, 'LED')
      .replace(/\bUsb\b/g, 'USB');
  }

  private formatLotSize(
    lotSize: number,
    lotSizeUnit:
      NonNullable<
        MarketplaceListing['lotSizeUnit']
      >
  ): string {
    if (lotSizeUnit === 'square_feet') {
      const formattedSquareFeet =
        new Intl.NumberFormat(
          'en-US',
          {
            maximumFractionDigits: 0
          }
        ).format(lotSize);

      return `${formattedSquareFeet} sq. ft.`;
    }

    const formattedAcres =
      new Intl.NumberFormat(
        'en-US',
        {
          minimumFractionDigits: 0,
          maximumFractionDigits: 2
        }
      ).format(lotSize);

    return formattedAcres === '1'
      ? '1 acre'
      : `${formattedAcres} acres`;
  }

  private formatCurrency(
    amount: number
  ): string {
    return new Intl.NumberFormat(
      'en-US',
      {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
      }
    ).format(amount);
  }

  protected getMonthlyHoaFee(
    hoa: MarketplaceListing['hoa']
  ): number {
    console.log(
      'HOA received by listing details:',
      hoa
    );

    if (
      !hoa?.hasHoa ||
      hoa.feeAmount === undefined
    ) {
      return 0;
    }

    switch (hoa.feeFrequency) {
      case 'monthly':
        return hoa.feeAmount;

      case 'quarterly':
        return hoa.feeAmount / 3;

      case 'semi_annually':
        return hoa.feeAmount / 6;

      case 'annually':
        return hoa.feeAmount / 12;

      default:
        return 0;
    }
  }

  protected estimateAnnualPropertyTax(
    listing: MarketplaceListing,
  ): number {
    return this.mortgageCostEstimationService
      .estimateAnnualPropertyTax(
        listing.price,
        listing.address
          .stateAbbreviation,
        listing.annualPropertyTax,
      );
  }

  protected estimateAnnualHomeownersInsurance(
    listing: MarketplaceListing,
  ): number {
    return this.mortgageCostEstimationService
      .estimateAnnualHomeownersInsurance(
        listing.price,
        listing.address
          .stateAbbreviation,
        listing
          .annualHomeownersInsurance,
      );
  }

  private formatHoaFrequency(
    frequency: string
  ): string {
    switch (frequency) {
      case 'monthly':
        return 'monthly';

      case 'quarterly':
        return 'quarterly';

      case 'semi_annually':
        return 'semi-annually';

      case 'annually':
        return 'annually';

      default:
        return frequency;
    }
  }

  private formatPropertyType(
    propertyType:
      MarketplaceListing['propertyType']
  ): string {
    switch (propertyType) {
      case 'single_family':
        return 'Single-family home';

      case 'condo':
        return 'Condo';

      case 'townhome':
        return 'Townhome';

      case 'multifamily':
        return 'Multifamily';

      case 'manufactured':
        return 'Manufactured home';

      case 'land':
        return 'Land';

      case 'farm':
        return 'Farm';

      case 'other':
      default:
        return 'Other';
    }
  }
}