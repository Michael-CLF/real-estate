import { isFederalLeadExcluded } from './state-contracts/federal-lead-policy';
import { readMissingListingDisclosures } from './listing-disclosure-gate-reader';
import { HttpsError } from 'firebase-functions/v2/https';

import type {
  DocumentReference,
  Transaction,
} from 'firebase-admin/firestore';

export function coloradoRequiredDisclosureTypes(
  listing: Record<string, unknown>,
): string[] {

  return [
    'colorado-property-disclosure',
    'colorado-radon-brochure',

    ...(!isFederalLeadExcluded(listing)
      ? ['lead-based-paint']
      : []),
  ];
}

/** Check Colorado documents required before offer creation. */
export async function assertColoradoListingDisclosures(
  transaction: Transaction,
  listingReference: DocumentReference,
  listing: Record<string, unknown>,
): Promise<void> {
  const required = coloradoRequiredDisclosureTypes(listing);

  const missing = await readMissingListingDisclosures(transaction, listingReference, required, file => {
    return (
      !file ||
      file['listingUid'] !== listingReference.id ||
      file['stateAbbreviation'] !== 'CO' ||
      !file['storagePath'] ||
      !file['versionId']
    );
  });

  if (missing.length) {
    throw new HttpsError(
      'failed-precondition',
      `The seller must upload ${missing
        .map(documentType => documentType.replace(/-/g, ' '))
        .join(', ')} in Property Disclosures before an offer can be made.`,
    );
  }
}