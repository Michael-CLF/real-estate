import { formatTimestamp } from '../property-time-format';

import PDFDocument from 'pdfkit';
import type { GenerateStateAgreementInput, GeneratedStateAgreement } from '../state-contract-package';
import type { NewMexicoOfferTermsDocument } from './new-mexico-offer-terms.document';
import type { OfferVersionPartySnapshotDocument } from '../../offer-types';
import {
  NAVSTREET_PDF,
  drawNavStreetNotice,
  drawNavStreetPdfChrome,
  drawNavStreetSectionBar,
  registerNavStreetPdfFonts,
} from '../navstreet-pdf-layout';

/** Renders NavStreet-authored terms; seller disclosures remain separate signed attachments. */
export async function generateNewMexicoOfferPdf(input: GenerateStateAgreementInput<NewMexicoOfferTermsDocument>): Promise<GeneratedStateAgreement> {
  const t = input.version.terms;
  const isCondominium = t.contractType === 'navstreet_new_mexico_condominium_resale_2026';
  const pdf = new PDFDocument({ size: 'LETTER', margins: { top: NAVSTREET_PDF.contentTop, right: NAVSTREET_PDF.margin, bottom: 58, left: NAVSTREET_PDF.margin }, bufferPages: true, info: { Title: input.documentTitle, Author: 'NavStreet', Subject: `${input.documentTitle} - ${input.offer.referenceNumber}`, Keywords: 'NavStreet, New Mexico, residential real estate, purchase agreement', CreationDate: input.generatedAt } });
  registerNavStreetPdfFonts(pdf);
  const chunks: Buffer[] = [];
  pdf.on('data', chunk => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
  const done = new Promise<Buffer>((resolve, reject) => { pdf.on('end', () => resolve(Buffer.concat(chunks))); pdf.on('error', reject); });
  function page(title: string): void {
    pdf.addPage();
    pdf.y = NAVSTREET_PDF.contentTop;
    drawNavStreetSectionBar(pdf, title);
  }
  function line(label: string, value: unknown): void {
    const text = String(value ?? 'Not specified');
    pdf.font('NavStreet-Regular').fontSize(9);
    const height = Math.max(27, pdf.heightOfString(text || ' ', { width: 324, lineGap: 2 }) + 12);
    if (pdf.y + height > NAVSTREET_PDF.contentBottom) page('Parties and property (continued)');
    const y = pdf.y;
    pdf.rect(NAVSTREET_PDF.margin, y, NAVSTREET_PDF.contentWidth, height - 2).fill(NAVSTREET_PDF.pale);
    pdf.font('NavStreet-Bold').fillColor(NAVSTREET_PDF.ink).fontSize(9)
      .text(label, NAVSTREET_PDF.margin + 10, y + 7, { width: 170, characterSpacing: 0 });
    pdf.font('NavStreet-Regular').fillColor(NAVSTREET_PDF.ink).fontSize(9)
      .text(text || ' ', NAVSTREET_PDF.margin + 192, y + 7, { width: 324, lineGap: 2, characterSpacing: 0 });
    pdf.y = y + height;
  }
  function clause(label: string, body: string): void {
    pdf.font('NavStreet-Regular').fontSize(9.5);
    const fullHeight = pdf.heightOfString(body, {width:NAVSTREET_PDF.contentWidth - 20,lineGap:2.5,characterSpacing:0}) + 45;
    if (fullHeight < NAVSTREET_PDF.contentBottom - NAVSTREET_PDF.contentTop - 40 && pdf.y + fullHeight > NAVSTREET_PDF.contentBottom) page('New Mexico agreement (continued)');
    const words = body.split(/\s+/);
    let continued = false;
    while (words.length) {
      if (pdf.y + 95 > NAVSTREET_PDF.contentBottom) page('New Mexico agreement (continued)');
      const y = pdf.y + 8;
      pdf.rect(NAVSTREET_PDF.margin, y, NAVSTREET_PDF.contentWidth, 20).fill(NAVSTREET_PDF.blue);
      pdf.font('NavStreet-Bold').fillColor('#FFFFFF').fontSize(8.5).text((label + (continued ? ' (continued)' : '')).toUpperCase(), NAVSTREET_PDF.margin + 10, y + 5, {width: NAVSTREET_PDF.contentWidth - 20, characterSpacing: 0});
      pdf.y = y + 29;
      pdf.font('NavStreet-Regular').fontSize(9.5);
      const available = NAVSTREET_PDF.contentBottom - pdf.y - 10;
      let count = 1;
      while (count < words.length && pdf.heightOfString(words.slice(0,count + 1).join(' '), {width:NAVSTREET_PDF.contentWidth - 20,lineGap:2.5,characterSpacing:0}) <= available) count++;
      const chunk = words.splice(0,count).join(' ');
      pdf.fillColor(NAVSTREET_PDF.ink).text(chunk,NAVSTREET_PDF.margin + 10,pdf.y,{width:NAVSTREET_PDF.contentWidth - 20,lineGap:2.5,characterSpacing:0});
      pdf.y += 8;
      if (words.length) {page('New Mexico agreement (continued)');continued = true;}
    }
  }
  const money = (cents: number) => `$${(cents / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  const receiptLabel = (value: string) => value === 'built_1978_or_later' ? 'Listing records construction after 1977' : value === 'exempt' ? 'Signed federal exemption evidence received' : value === 'unselected' ? 'Not answered' : value.replace(/_/g, ' ');
  const answer = (v: boolean | null) => v === null ? 'No selection' : v ? 'Yes' : 'No';
  const names = (parties: OfferVersionPartySnapshotDocument[]) => parties.map(p => p.legalName).join('; ');
  pdf.y = NAVSTREET_PDF.contentTop;
  drawNavStreetNotice(pdf, isCondominium ? 'New Mexico condominium resale purchase offer' : 'New Mexico residential purchase offer', 'Original NavStreet agreement for an ordinary residential resale. Required seller disclosures remain separate uploaded documents. Acceptance requires all required parties to sign the same version and communicate acceptance. Read all terms and attachments before signing.');
  drawNavStreetSectionBar(pdf, 'Parties, property and negotiated terms');
  if (isCondominium) line('Agreement identity', 'navstreet_new_mexico_condominium_resale_2026 / navstreet-nm-condominium-2026 / revision 2026-10-22');
  line('Property', [t.property.addressLine1, t.property.addressLine2, t.property.city, 'NewMexico', t.property.zipCode].filter(Boolean).join(', '));
  line('County / parcel', `${t.property.county || 'Unspecified'} / ${t.property.parcelIdentificationNumber || 'Unspecified'}`);
  line('Property time zone', t.delivery.timeZone);
  line('Legal description', t.legalDescription);
  line('Buyer(s)', names(input.version.buyers)); line('Seller(s)', names(input.version.sellers));
  clause('1. Purchase and written agreement', `Buyer offers to purchase the identified property from seller for ${money(t.purchase.purchasePriceInCents)}. Seller concessions toward buyer expenses: ${money(t.purchase.sellerConcessionsInCents)}. This version becomes binding upon the required signatures and communication of acceptance. The effective date is the final required acceptance signature date, provided acceptance is communicated. A counteroffer is a new version requiring new signatures. Parties shall identify all owners and required signers; signing this offer does not dispense with spouses or other persons whose joinder is required for a valid conveyance.`);
  clause('2. Earnest money', t.purchase.hasEarnestMoney ? `Buyer shall deliver ${money(t.purchase.earnestMoneyInCents)} to ${t.purchase.earnestMoneyHolder} within ${t.purchase.earnestMoneyDueDays} calendar days after the effective date. ${t.conditions.additionalEarnestMoney ? `Additional earnest money of ${money(t.purchase.additionalEarnestMoneyInCents)} is due within ${t.purchase.additionalEarnestMoneyDueDays} calendar days after the effective date.` : 'No additional deposit is due.'} Deposits are credited to buyer at closing. The holder shall maintain and disburse them under this agreement and applicable law. Disputed funds require lawful disbursement, signed joint instructions or a court order.` : 'No earnest money deposit is required by this version.');
  clause('3. Included property and leases', `Existing improvements and installed fixtures are included except those expressly excluded. Additional personal property included: ${t.propertyItems.included || 'None specified'}. Exclusions: ${t.propertyItems.excluded || 'None specified'}. Leased equipment and proposed assignments: ${t.propertyItems.leasedItemsDescription || 'None specified'}. Seller shall identify existing tenancies and leases. Any continuing tenancy, equipment lease or post-closing occupancy requires separately signed arrangements and applicable third-party consent. This agreement alone does not assign a third-party lease.`);
  page('Conditions, title and closing');
  clause('4. Financing', `Funding: ${t.purchase.financingType}. ${t.purchase.financingType === 'cash' ? 'Buyer will pay cash and has no financing or appraisal condition.' : `Proposed loan: ${money(t.purchase.loanAmountInCents)} over ${t.purchase.loanTermYears} years. Loan approval condition: ${answer(t.conditions.financing)}. Appraisal condition: ${answer(t.conditions.appraisal)}. ${t.conditions.financing ? `Buyer shall apply in good faith within ${t.purchase.loanApplicationDays} calendar days after the effective date and seek approval within ${t.purchase.loanApprovalDays} calendar days after the effective date. Buyer may terminate by written notice delivered within that approval period if the loan cannot be obtained despite good-faith efforts; the deposit shall be returned subject to lawful escrow disbursement.` : 'Buyer assumes the financing risk without a loan-approval cancellation right.'} ${t.conditions.appraisal ? `If the lender appraisal is insufficient for the stated loan, buyer may terminate by written notice within ${t.purchase.loanApprovalDays} calendar days after the effective date and recover the deposit, unless different terms are agreed in writing.` : 'No appraisal cancellation right is selected.'}`} Purchase conditioned on sale of buyer’s other property: ${answer(t.conditions.saleOfBuyersProperty)}. If selected, the identified property, sale deadline and cancellation consequences must be written in Additional terms.`);
  clause('5. Inspection and condition', `Buyer has ${t.deadlines.inspectionPeriodDays} calendar days after the effective date to inspect the property, including structural, environmental, radon, water, sewer and septic conditions as appropriate. Buyer may terminate by written notice delivered before the inspection period expires if the property is unacceptable, and the deposit shall be returned subject to lawful escrow disbursement. Buyer shall repair damage caused by inspections. Seller has no obligation to make requested repairs unless agreed in writing. Seller shall maintain the property substantially in its acceptance condition, ordinary wear excepted. Inspection rights do not waive statutory disclosures, fraud remedies or other nonwaivable rights.`);
  clause('6. Time and closing date', `Closing shall occur by ${t.deadlines.settlementDate}. Optional additional document date: ${t.deadlines.sellerDisclosureDate || 'None'}. Contract periods measured in calendar days begin on the day following the effective date and expire at 11:59 p.m. in ${t.delivery.timeZone}. A fixed contract date expires at that same property-local time. Statutory periods use their own governing rules. The optional document date does not extend a statutory delivery deadline. Offer expiration: ${formatTimestamp(new Date(t.delivery.expiresAt), t.delivery.timeZone)}.`);
  clause('7. Title and conveyance', `Closing agent: ${t.settlement.closingAgentName}. The owner’s title insurance policy and search are paid by ${t.settlement.titlePolicyPayer}. Seller shall provide evidence of marketable title at least ${t.settlement.titleEvidenceDaysBeforeClosing} calendar days before closing. Buyer shall promptly identify title objections in writing. Seller shall cure objections by closing or obtain an agreed written extension. If an uncured objection prevents marketable title, buyer may terminate and recover deposits or accept the defect in writing. Seller shall convey by recordable deed, free of liens requiring payoff, subject to recorded exceptions accepted by buyer. All legally necessary owners and spouses must join in conveyance. This agreement does not provide seller financing or an installment contract for deed.`);
  clause('8. Allocations, casualty and possession', `Taxes, periodic dues and utilities shall be prorated at closing using available current information, with later adjustment by written agreement if needed. Seller is responsible for seller’s liens and obligations that must be discharged to convey title. Pre-closing special assessments are paid by ${t.settlement.specialAssessmentPayer}; association transfer fees, if applicable, by ${t.disclosures.sellerReportsHoa ? t.settlement.hoaTransferFeePayer : 'not applicable'}. Material casualty before closing permits buyer to terminate and recover deposits or agree in writing to restoration or assignment of available insurance rights. Seller shall deliver vacant possession and keys at closing unless a separately signed occupancy or tenancy agreement states otherwise.`);
  page('State disclosures and protected rights');
  clause('9. Separate disclosures and actual receipt', `Seller disclosure or signed exception evidence: ${t.disclosures.propertyConditionStatus === 'exempt' ? 'Signed New Mexico statutory exemption evidence reviewed' : receiptLabel(t.disclosures.propertyConditionStatus)}. Property-specific statutory/local packet: ${receiptLabel(t.disclosures.statutoryPacketStatus)}. Seller reports an association: ${answer(t.disclosures.sellerReportsHoa)}; association documents: ${receiptLabel(t.disclosures.hoaDocumentsStatus)}. Seller reports existing leases: ${answer(t.disclosures.sellerReportsExistingLeases)}; buyer reviewed the lease statement: ${answer(t.disclosures.leaseStatementAcknowledged)}. A received status records the buyer’s actual review of the uploaded document, including any identified exception evidence; it does not certify the truth of seller statements or waive protected rights. Seller must promptly provide applicable written amendments and updated information before closing.`);
  clause("New Mexico condition information", "This ordinary resale package does not impose a universal state-prescribed seller condition form as a prerequisite to an offer. Seller shall disclose known adverse material facts and shall not misrepresent or actively conceal conditions. A voluntarily supplied condition statement is not a warranty or substitute for inspection. Professional broker duties under 16.61.19 NMAC apply to licensed brokers; they do not make NavStreet a broker or create a statewide FSBO form requirement. A receipt answer records actual delivery, not a completed or signed separate statement.");
  clause("New Mexico assessor tax estimate before acceptance", t.documentVersions ? "Before seller acceptance, request and provide the county assessor written tax-levy estimate at the listed price, including the statutory warning; buyer must acknowledge written receipt. NavStreet collects this document before online offers open. If the assessor estimate is not readily available, seller provides supporting evidence and each buyer must expressly execute the NMSA 47-13-4(F) waiver before making the offer. A current seller tax bill alone is not the estimate. Receipt of unavailability evidence does not acknowledge receipt of an estimate. The buyer waiver below, when selected and signed, applies only to the unavailable estimate and does not waive hazard notices or other nonwaivable protections." : "Under NMSA 47-13-4, before accepting an offer the seller or seller broker shall request the county assessor tax-levy estimate at the listed price and provide the written response to buyer or buyer broker. The response includes current/prior taxes, the estimated following-year levy and the statutory warning about the stated price, current-and-correct value and actual future rates. A current seller tax bill alone is insufficient. County online printable estimates may satisfy the response requirement. When the statutory packet is marked Received, buyer electronic signature and timestamp expressly acknowledge written receipt of the assessor estimate. Pending is not an acknowledgment. Buyer may send an offer while the estimate is pending; seller acceptance requires its delivery and recorded buyer receipt. No state tax-estimate requirement is invented at draft creation.");
  if (!isCondominium) clause("New Mexico HOA certificate and cancellation", "For a covered HOA lot under NMSA 47-16-11 through 47-16-13, seller shall supply the association disclosure certificate no later than seven days before closing and the applicable declaration, bylaws, covenants and rules before closing. Buyer may cancel within seven days after receipt of the certificate through the statutory notice method, without penalty; payments are refunded within fifteen days. A pending HOA certificate does not universally block offer creation. Verify actual statutory applicability and supported exceptions; condominium offerings are outside this package. Preserve statutory certificate, assessment and cancellation protections despite a separate negotiated inspection deadline.");
  clause("New Mexico on-site liquid waste systems", "For an established on-site liquid waste system, seller shall arrange the qualified NMED property-transfer evaluation before transfer, required permitting/registration and correction of deficiencies under 20.7.3 NMAC. Evaluation reports go to NMED within fifteen days. Verify report validity and any approved extension; advanced treatment, alternative disposal and holding-tank systems require applicable ownership and operating/maintenance updates. This is a transfer requirement, not a universal pre-offer evaluation. Seller shall provide records and meet required compliance before closing; buyer may terminate before settlement if required transfer compliance is not achieved, subject to lawful return of deposits.");
  clause("New Mexico clandestine laboratory notice", "Where 20.4.5 NMAC applies, owner shall give written notice of a clandestine drug laboratory to a proposed transferee, obtain the transferee written acknowledgment, and supply copies to NMED Hazardous Waste Bureau as required by 20.4.5.13. No unauthorized entry or occupancy is permitted while residual contamination remains subject to the notice. Separately execute the notice and acknowledgment and verify department-approved remediation before occupancy. A signed purchase agreement or generic packet status does not certify cleanup, authorize entry or submit notices to NMED. Seller must comply before transfer; known contamination is not made harmless by an as-is provision.");
  clause("New Mexico title, water and community property", "Closing shall verify recorded legal description, ownership, title insurance, community-property/spousal joinder and acknowledged deed requirements. Seller-owned appurtenant water rights intended to convey shall be expressly identified in the deed unless lawfully reserved; provide OSE records and perform applicable county/OSE ownership updates. A well or irrigation use does not by itself establish transferable water rights. Review shared-well agreements, acequia/ditch obligations, legal access and local permits during inspection. The existing seller tax valuation is not a guarantee of buyer taxes. Federal and state withholding and sales-information reporting remain the closing agent responsibilities.");
  if (t.disclosures.taxEstimateUnavailable && t.disclosures.taxEstimateWaived === true) clause('Buyer statutory tax-estimate waiver - signed before offer', 'Each buyer signing and sending this offer acknowledges that the county assessor estimated property-tax levy is not readily available and expressly waives its disclosure under NMSA 47-13-4(F) before making this offer. Seller supporting evidence is the exact statutory-packet version identified below. This does not waive known hazard disclosures or other nonwaivable rights.');
  if (isCondominium) clause('New Mexico condominium resale rights', "Seller conveys the recorded condominium unit together with appurtenant common-element interests, limited common-element assignments and easements, subject to recorded transfer restrictions. For a resale subject to NMSA 47-7D-9, seller shall furnish before conveyance the declaration excluding plats/plans, bylaws, rules and association resale certificate covering transfer restraints; current and unpaid assessments; other fees; capital expenditures for the current and next two fiscal years; reserves; recent financial statements; operating budget; judgments; insurance; and any leasehold term. The contract is voidable by buyer until the certificate is furnished and for seven days thereafter, or until conveyance, whichever first. Cancellation is without penalty and deposits shall be promptly refunded. Seller is not liable for erroneous association information or its failure/delay to supply the certificate to the extent the statute protects seller. Verify applicability under 47-7A-2 for older condominiums and exceptions under 47-7D-1(B); where statutory resale-certificate protection does not apply, the parties grant the same document-delivery and seven-day review/cancellation protection contractually. No initial-offer receipt or upload is invented. No waiver of nonwaivable rights. Developer, timeshare, conversion/developer disclosure-statement and leasehold sale paths are excluded.");
  for (const [type,versionId] of Object.entries(t.documentVersions ?? {})) line('Reviewed disclosure version', type + ' / ' + versionId);
  if (!t.documentVersions || !(typeof t.property.yearBuilt === 'number' && t.property.yearBuilt >= 1978)) clause('Federal lead disclosure and inspection', `Lead packet status: ${receiptLabel(t.disclosures.leadPaintStatus)}. For covered pre-1978 housing, seller shall provide known lead information, available reports, the signed federal statement and EPA pamphlet before buyer is bound. Inspection selection: ${t.disclosures.leadPaintStatus === 'received' ? t.disclosures.leadInspectionSelection === 'ten_days' ? '10 days' : t.disclosures.leadInspectionSelection === 'other_period' ? `${t.disclosures.leadInspectionDays} days agreed in writing` : 'Buyer waives the inspection opportunity in writing' : 'See separate exemption evidence or post-1977 construction record'}. The inspection opportunity runs before buyer becomes bound unless the parties agree to a different period in writing. Choosing 10 days does not defer mandatory disclosures until after acceptance. Waiver of inspection does not waive disclosure. The required federal warning and certifications remain in the separately signed lead attachment, which must be retained for the required period.`);
  clause('10. Default and remedies', 'A party’s material failure to perform permits the other party to give written notice and pursue available remedies under New Mexico law, subject to any applicable notice, cure or statutory requirements. No automatic forfeiture or exclusive remedy is created here. The parties may obtain independent advice about damages, performance, cancellation and lawful escrow disbursement. Statutory and nonwaivable rights are preserved.');
  clause('11. Notices and electronic consent', `The initiating party’s express electronic delivery and signing consent: ${answer(t.delivery.electronicDeliveryAuthorized)}. Each later signer must separately consent in the signing workflow; this entry does not supply consent for another person. Contract notices must be written and delivered to the parties’ designated addresses or electronic destinations where legally permitted. Statutory notice methods and periods apply when required by law. This offer expires at the stated time unless the required initiating signatures and delivery occur before expiration.`);
  clause('12. Additional negotiated terms', t.additionalTerms || 'None.');
  if (isCondominium) clause('13. Entire agreement and amendments', 'This immutable version and expressly identified signed attachments constitute the agreement. Changes require a signed written version. Additional terms cannot override statutory protections. Parties may obtain independent legal advice before signing.');
  if (isCondominium) clause('Condominium scope', 'This is an ordinary existing fee-simple residential condominium resale. Developer, new construction, vacant land, leasehold, manufactured-home and multifamily transactions are outside its scope.');
  if (!isCondominium) clause('13. Entire agreement and amendments', 'This version and expressly identified signed attachments constitute the agreement. Amendments require a signed written version. Additional terms cannot override nonwaivable statutory protections. Parties have the opportunity to obtain independent legal advice before signing. This resale agreement does not cover condominium/developer offerings, new-construction sales, vacant land, installment seller financing or other transactions requiring a different agreement.');
  page('Version signatures');
  const requiredParties = [...input.version.buyers, ...input.version.sellers].filter(party => party.requiredSigner);
  const allSigned = requiredParties.length > 0 && requiredParties.every(party =>
    party.signature.status === 'signed' && party.signature.signedAt);
  line('Document status', input.documentStatus === 'approved' && allSigned
    ? 'Final accepted version' : 'Offer version - signatures pending');
  line('Version created', formatTimestamp(input.version.createdAt?.toDate(), t.delivery.timeZone));
  for (const [label, parties] of [['Buyers', input.version.buyers], ['Sellers', input.version.sellers]] as const) {
    pdf.moveDown();
    drawNavStreetSectionBar(pdf, label);
    for (const party of parties) {
      if (pdf.y > 590) page('Version signatures (continued)');
      const signed = party.signature.status === 'signed' && party.signature.signedAt;
      line('Party', party.legalName);
      line('Electronic signature', signed ? `/s/ ${party.legalName}` : 'Awaiting signature');
      line('Signed (property time)', signed ? formatTimestamp(party.signature.signedAt?.toDate(), t.delivery.timeZone) : 'Pending');
      pdf.y += 6;
    }
  }
  if (input.documentStatus === 'approved' && allSigned) {
    const signed = [...input.version.buyers, ...input.version.sellers].filter(p => p.requiredSigner).map(p => p.signature.signedAt?.toDate()).filter((v): v is Date => Boolean(v));
    if (signed.length) line('Effective signature time (property time)', formatTimestamp(new Date(Math.max(...signed.map(d => d.getTime()))), t.delivery.timeZone));
  }
  const pageCount = pdf.bufferedPageRange().count;
  for (let index = 0; index < pageCount; index++) {
    pdf.switchToPage(index);
    // Footer text is outside the body margin; keep it on the current page.
    pdf.page.margins.bottom = 0;
    drawNavStreetPdfChrome(pdf, {
      stateName: 'New Mexico',
      ...(isCondominium ? {agreementTitle:'New Mexico CONDOMINIUM RESALE PURCHASE\nAND SALE AGREEMENT'} : {}),
      referenceNumber: input.offer.referenceNumber,
      versionNumber: input.version.versionNumber,
      pageNumber: index + 1,
      pageCount,
    });
  }
  pdf.end();
  return { buffer: await done, fileName: `NavStreet-NM-${input.offer.referenceNumber}-v${input.version.versionNumber}.pdf`, pageCount };
}
